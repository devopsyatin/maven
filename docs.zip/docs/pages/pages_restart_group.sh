#!/bin/sh
set -x
F5=eqav-f5.postdirect.com
echo "removing group1 from F5, restarting group1, adding back to F5"
ssh -tq $F5 "modify ltm pool pool_cseqa.pages.yesmail.com_80 members modify {192.168.36.117:80 { session user-disabled } };quit"
ssh -tq $F5 "modify ltm pool pool_cseqa.pages.yesmail.com_80 members modify {192.168.36.117:80 { state user-down } };quit"
ssh -tq $F5 "modify ltm pool pool_control-stress.emailmarketing.com members modify {estressv-uiapache01:80 { session user-disabled } };quit"
ssh -tq $F5 "modify ltm pool pool_control-stress.emailmarketing.com members modify {estressv-uiapache01:80 { state user-down } };quit"
ssh -tq $F5 "run cm config-sync to-group /Common/qaf5_ha;quit"
sleep 10
SYNC=`ssh -tq eqav-f5.postdirect.com 'show cm sync-status' |grep "Status  " |awk '{print $2$3}'`
echo "F5 is $SYNC"
MSTATE01=`ssh -tq eqav-f5.postdirect.com 'show ltm pool pool_cseqa.pages.yesmail.com_80 members {192.168.36.117:80} all-properties' |grep "State          :" |cut -d":" -f2 |awk ' {print $1} '`
MSTATE02=`ssh -tq eqav-f5.postdirect.com 'show ltm pool pool_control-stress.emailmarketing.com members {estressv-uiapache01:80} all-properties' |grep "State          :" |cut -d":" -f2 |awk ' {print $1} '`
if [ "$MSTATE01" == "disabled" ] && [ "$MSTATE02" == "disabled" ];
          then
        echo "All Good to Proceed"


check_connections1()
{
active_connections1=`ssh -tq eqav-f5.postdirect.com 'show ltm pool pool_cseqa.pages.yesmail.com_80 members {192.168.36.117:80} all-properties' |grep "|   Current Connections" | awk -F" " '{ print $4 }'`
echo "current active connections are $active_connections1"
}

check_connections2()
{
active_connections2=`ssh -tq eqav-f5.postdirect.com 'show ltm pool pool_control-stress.emailmarketing.com members {estressv-uiapache01:80} all-properties' |grep "|   Current Connections" | awk -F" " '{ print $4 }'`
echo "current active connections are $active_connections2"
}

restart_F5Enable()
{
ssh -tq 192.168.36.117 "sudo /etc/init.d/httpd status"
ssh -tq estressv-uiapache01 "sudo /etc/init.d/httpd status"
sleep 30
ssh -tq 192.168.36.117 "sudo /etc/init.d/pages-linux status"
ssh -tq estressv-pages01 "sudo /etc/init.d/pages-linux status"
sleep 5
ssh -tq $F5 "modify ltm pool pool_cseqa.pages.yesmail.com_80 members modify {192.168.36.117:80 { state user-up } };quit"
ssh -tq $F5 "modify ltm pool pool_cseqa.pages.yesmail.com_80 members modify {192.168.36.117:80 { session user-enabled} };quit"
ssh -tq $F5 "modify ltm pool pool_control-stress.emailmarketing.com members modify {estressv-uiapache01:80 { state user-up } };quit"
ssh -tq $F5 "modify ltm pool pool_control-stress.emailmarketing.com members modify {estressv-uiapache01:80 { session user-enabled} };quit"
ssh -tq $F5 "run cm config-sync to-group /Common/qaf5_ha;quit"
ASTATE1=`ssh -tq eqav-f5.postdirect.com 'show ltm pool pool_cseqa.pages.yesmail.com_80 members {192.168.36.117:80} all-properties' |grep "State          :" |cut -d":" -f2 |awk ' {print $1} '`
ASTATE2=`ssh -tq eqav-f5.postdirect.com 'show ltm pool pool_control-stress.emailmarketing.com members {estressv-uiapache01:80} all-properties' |grep "State          :" |cut -d":" -f2 |awk ' {print $1} '`
until [ "$ASTATE1" == "enabled" ] && [ "$ASTATE2" == "enabled" ]; do
echo "nodes are "$ASTATE""
echo "F5 is `ssh -tq eqav-f5.postdirect.com 'show cm sync-status' |grep "Status  " |awk '{print $2$3}'`"
done

}

check_connections1;
check_connections2;

	if [[ $active_connections1 -le 20  &&  $active_connections2 -le 20 ]];

	then
		restart_F5Enable;

	else	
		count=0
		Total=5
		until [ $active_connections1 -le 20 ]  &&  [ $active_connections2 -le 20 ];
		do
		sleep 10
		count=$((count + 1))
		if [ $count == $Total ];
                then
                read -p "Do you want to wait more for count to come down? Yes/No" ans
		echo "Your ans is $ans"
                if [ $ans == No ];
                then
                        restart_F5Enable;
			exit
                else
                        Total=$((Total + 5))
				
		check_connections1;
		check_connections2;
		fi
		fi
		done
		restart_F5Enable;
	fi	

else
echo "Something is not right"
fi
