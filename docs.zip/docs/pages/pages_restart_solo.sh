#!/bin/sh
set -x
F5=eqav-f5.postdirect.com
echo "removing 192.168.36.117 from F5, restarting 192.168.36.117, adding back to F5"
ssh -tq $F5 "modify ltm pool pool_cseqa.pages.yesmail.com_80 members modify {192.168.36.117:80 { session user-disabled } };quit"
ssh -tq $F5 "modify ltm pool pool_cseqa.pages.yesmail.com_80 members modify {192.168.36.117:80 { state user-down } };quit"
ssh -tq $F5 "run cm config-sync to-group /Common/qaf5_ha;quit"
sleep 10
SYNC=`ssh -tq eqav-f5.postdirect.com 'show cm sync-status' |grep "Status  " |awk '{print $2$3}'`
echo "F5 is $SYNC"
MSTATE=`ssh -tq eqav-f5.postdirect.com 'show ltm pool pool_cseqa.pages.yesmail.com_80 members {192.168.36.117:80} all-properties' |grep "State          :" |cut -d":" -f2 |awk ' {print $1} '`
if [ "$MSTATE" == "disabled" ];
        then
        echo "All Good to Proceed"

restart_F5Enable()
{
        ssh -tq 192.168.36.117 "sudo /etc/init.d/httpd status"
        sleep 30
        ssh -tq 192.168.36.117 "sudo /etc/init.d/pages-linux status"
        ssh -tq $F5 "modify ltm pool pool_cseqa.pages.yesmail.com_80 members modify {192.168.36.117:80 { state user-up } };quit"
        ssh -tq $F5 "modify ltm pool pool_cseqa.pages.yesmail.com_80 members modify {192.168.36.117:80 { session user-enabled} };quit"
        ssh -tq $F5 "run cm config-sync to-group /Common/qaf5_ha;quit"
        ASTATE=`ssh -tq eqav-f5.postdirect.com 'show ltm pool pool_cseqa.pages.yesmail.com_80 members {192.168.36.117:80} all-properties' |grep "State          :" |cut -d":" -f2 |awk ' {print $1} '`
        until [ "$ASTATE" == "enabled" ]; do
        echo "node is "$ASTATE""
        echo "F5 is `ssh -tq eqav-f5.postdirect.com 'show cm sync-status' |grep "Status  " |awk '{print $2$3}'`"
        done
}



check_connections()
{
active_connections=`ssh -tq eqav-f5.postdirect.com 'show ltm pool pool_cseqa.pages.yesmail.com_80 members {192.168.36.117:80} all-properties' |grep "|   Current Connections" | awk -F" " '{ print $4 }'`
echo "current active connections are $active_connections"
}
check_connections;

	if [ $active_connections -le 20 ];

	then
		echo "reached 1"
		restart_F5Enable;
	else
	
		while [ $active_connections -gt 30 ];
		do
		sleep 20
		check_connections;
		done
		restart_F5Enable;
	fi	
#	if $active_connections > 70;
#	then
#	echo "do you want to override the wait process and proceed further"
		

else
echo "Something is not right"
fi
