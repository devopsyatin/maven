#!/bin/bash
set -x
for i in `cat /home/yatins/scripts/Serverlists/Serverlist_ProdPatch`;
do 

	ssh -tq f5.postdirect.com "modify ltm node $i session user-disabled";
	sleep 2
	ssh -tq f5.postdirect.com "modify ltm node $i State user-down";
#	sleep 5
done

ssh -tq f5.postdirect.com "run cm config-sync to-group High-Availability-Pair";
