#!/bin/bash
set -x
for i in `cat /home/yatins/scripts/Serverlists/Serverlist_ProdPatch`;
do 

	echo $i;
	ssh -tq f5.postdirect.com "show ltm node $i" |grep -A4 State| grep -v  "Reason         :" | grep -v "Monitor        :" | grep -v "Monitor Status :";

done
