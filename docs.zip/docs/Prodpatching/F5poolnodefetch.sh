#!/bin/bash
set -x
for i in `cat /home/yatins/scripts/Serverlists/Serverlist_ProdPatch`;
do 

	echo $i;
	ssh -tq f5.postdirect.com "list ltm pool one-line" |grep -E $i | awk {' print $3'};

done
