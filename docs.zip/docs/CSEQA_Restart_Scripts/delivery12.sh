#!/bin/bash

clear
. /home/yatins/scripts/CSEQA_Restart_Scripts/CSEQA.env
printf "\033[1;31m The Delivery12 Servers for CSEQA are `echo $CSEQA_C12GEN` \033[0m\n"

for i in $CSEQA_C12GEN; do

############################ STOP / KILL PROCESS ################################

printf "\033[1;31m Current Running Processes on the $i servers are: \033[0m\n";
ssh -q $i "ps aux | grep "delivery12" |grep -v grep | awk '{print \$2}'";
printf "\033[1;31m Stopping the Delivery12 process id on $i \033[0m\n";
ssh -tq $i "sudo /etc/init.d/delivery12 stop";
printf "\033[1;31m Checking again if the Delivery12 process exists on $i \033[0m\n";
test=`ssh -q $i "ps aux | grep "delivery12" |grep -v grep | wc -l"` && echo $test;

        if [ $test -ne 0 ]; then
        echo "Process is not killed. Forcefully killing the process."
        ssh -q  $i "sudo kill -9 \$(ps aux | grep "delivery12" |grep -v grep | awk '{print \$2}')"
        sleep 5
        else
        echo "All Processes killed"
        fi

############################ START PROCESS ################################

printf "\033[1;31m Starting the Delivery12 process on $i \033[0m\n";
ssh -tq $i "sudo /etc/init.d/delivery12 start";
printf "\033[1;31m Confirming if the Delivery12 Process have been started on $i \033[0m\n";
ssh -tq $i "ps aux | grep "delivery12" |grep -v grep | awk '{print \$2}'";
test=`ssh -q $i "ps aux | grep "delivery12" |grep -v grep | wc -l"` && echo $test;

if [ $test -ne 0 ]; then
echo "Process Started"
else
echo "Process not started. Kindly Investigate."
exit
fi

done

