#!/bin/sh

clear
. /home/yatins/scripts/CSEQA_Restart_Scripts/CSEQA.env
printf "\033[1;31m The E7UI Servers for CSEQA are `echo $CSEQA_E7UI` \033[0m\n"

for i in $CSEQA_E7UI; do

############################ STOP / KILL PROCESS ################################

printf "\033[1;31m Current Running Processes on the $i servers are: \033[0m\n";
ssh -q $i "ps aux | grep "prod_ui7" |grep -v grep | awk '{print \$2}'";
printf "\033[1;31m Stopping the E7UI process id on $i \033[0m\n";
ssh -tq $i "sudo /etc/init.d/prod_ui7 stop";
printf "\033[1;31m Checking again if the E7UI process exists on $i \033[0m\n";
test=`ssh -q $i "ps aux | grep "prod_ui7" |grep -v grep | wc -l"` && echo $test;

        if [ $test -ne 0 ]; then
        echo "Process is not killed. Forcefully killing the process."
        ssh -q  $i "sudo kill -9 \$(ps aux | grep "prod_ui7" |grep -v grep | awk '{print \$2}')"
        sleep 5
        else
        echo "All Processes killed"
        fi

############################ START PROCESS ################################

printf "\033[1;31m Starting the E7UI process on $i \033[0m\n";
ssh -tq $i "sudo /etc/init.d/prod_ui7 start";
printf "\033[1;31m Confirming if the E7UI Process have been started on $i \033[0m\n";
ssh -q $i "ps aux | grep "prod_ui7" |grep -v grep | awk '{print \$2}'";
test=`ssh -q $i "ps aux | grep "prod_ui7" |grep -v grep | wc -l"` && echo $test;

if [ $test -ne 0 ]; then
echo "Process Started"
else
echo "Process not started. Kindly Investigate."
exit
fi

done

