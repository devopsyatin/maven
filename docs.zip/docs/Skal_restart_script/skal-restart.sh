#!/bin/bash
#This Script is for automation of the restart of SKAL Server Nodes/clusters.
#Writer of the script is YATIN SAWANT - OFFSHORE ASA CYBAGE TEAM
#If any Changes/modifications required in this script,Kindly get in touch with the Yatin Sawant or email at yatin.sawant@infogroup.com.

clear

display_menu()
{
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "       SKAL SERVER RESTART SCRIPT         "
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "1. cluster1-eprov-skal07/eprov-skal08"
echo "2. cluster2-eprov-skal10/eprov-skal11"
echo "3. cluster3-eprov-skal13/eprov-skal14"
echo "4. cluster4-eprov-skal1/eprov-skal2"
echo "5. Exit"

read_options() {
read -p "Enter Choice [1 -5] :  " choice
case $choice in 
	1) clus1;;
	2) clus2;;
	3) clus3;;
	4) clus4;;
	5) exit 0;;
	*) echo " " ; echo "Re-run script with proper choice/options" ; exit 0;;
esac
}
pause(){
	read -p "Press [Enter] key for Main Menu ..." factEnterkey
	display_menu
	read_options
}

clus1(){

webserv="http://kalservloc.postdirect.com/proxy"
keyword="eprov-skal07"
keyword1="eprov-skal08"
cluster="CLUSTER1"
if  curl -s "$webserv" | grep "$keyword" && curl -s "$webserv" | grep "$keyword1";

then    # if the keyword is in the content
        printf "\033[1;31m \nThe cluster1 contain nodes $keyword/$keyword1.\n \033[0m"
        sleep 5
else
        echo "Nodes are absent"
        printf "Do not proceed with restart"
	exit
fi

sleep 10
clear

starttime;


echo "checking primary node for cluster 1"

webserv1="http://kalservloc.postdirect.com/TRITONSPORTS"

if curl -s "$webserv1" | grep "$keyword";

then
	cond1;

else
	cond2;
fi

endtime;

}


clus2()
{
webserv="http://kalservloc.postdirect.com/proxy"
keyword="eprov-skal10"
keyword1="eprov-skal11"
cluster="CLUSTER2"
if  curl -s "$webserv" | grep "$keyword" && curl -s "$webserv" | grep "$keyword1";

then    # if the keyword is in the content
        printf "\033[1;31m \nThe cluster2 contain nodes $keyword/$keyword1.\n \033[0m"
        sleep 10
else
        echo "Nodes are absent"
        printf "Do not proceed with restart"
	exit
fi

sleep 10
clear

starttime;

echo "checking primary node for cluster 2"

webserv1="http://kalservloc.postdirect.com/NAPA"

if curl -s "$webserv1" | grep "$keyword";

then
	cond1;
else

	cond2;
fi

endtime;

}

clus3()
{
webserv="http://kalservloc.postdirect.com/proxy"
keyword="eprov-skal13"
keyword1="eprov-skal14"
cluster="CLUSTER3"
if  curl -s "$webserv" | grep "$keyword" && curl -s "$webserv" | grep "$keyword1";

then    # if the keyword is in the content
        printf "\033[1;31m \nThe cluster3 contain nodes $keyword/$keyword1.\n \033[0m"
        sleep 10
else
        echo "Nodes are absent"
        printf "Do not proceed with restart"
	exit
fi

sleep 10
clear

starttime;

echo "checking primary node for cluster 3"

webserv1="http://kalservloc.postdirect.com/PUREGYM"

if curl -s "$webserv1" | grep "$keyword";

then
	cond1;

else 
	cond2;

fi

endtime;


}

clus4()
{
webserv="http://kalservloc.postdirect.com/proxy"
keyword="eprov-skal01"
keyword1="eprov-skal02"
cluster="CLUSTER4"

if  curl -s "$webserv" | grep "$keyword" && curl -s "$webserv" | grep "$keyword1";

then    # if the keyword is in the content
        printf "\033[1;31m \nThe cluster4 contain nodes $keyword/$keyword1.\n \033[0m"
        sleep 10
else
        echo "Nodes are absent"
        printf "Do not proceed with restart"
	exit
fi

sleep 10
clear

starttime;

echo "checking primary node for cluster 4"

webserv1="http://kalservloc.postdirect.com/AEGWORLDWIDE"

if curl -s "$webserv1" | grep "$keyword";

then
	cond1;
else
	cond2;
fi

endtime;


}

cond1()

{
	printf "\033[1;31m The Primary node for Cluster is $keyword.\033[0m\n"
        printf "\033[1;31m The Secondary node for Cluster is $keyword1.\033[0m\n"
        printf "\033[1;31m Restarting Secondary node $keyword1.\033[0m\n"
        printf "\033[1;31m Current Running Process id's for user KAL@$keyword1 are: \033[0m\n"
        ssh -q $keyword1 "ps aux | grep "KALProxy.jar" |grep -v grep | awk '{print \$2}'"
        printf "\033[1;31m Killing the KALProxy.jar process id's on $keyword1 \033[0m\n"
        ssh -q  $keyword1 "sudo kill -9 \$(ps aux | grep "KALProxy.jar" |grep -v grep | awk '{print \$2}')"
        printf "\033[1;31m Checking again if the KALProxy.jar process exists on $keyword1 \033[0m\n"
        ssh -q $keyword1 "ps aux | grep "KALProxy.jar" |grep -v grep | wc -l"
        printf "\033[1;31m Starting the service again using user KAL@$keyword1 \033[0m\n"
        ssh -tq $keyword1 "sudo su - kal -c '/home/kal/KALProxy/current/start.sh &'"
        sleep 5
        printf "\033[1;31m Confirming if the KALProxy.jar Process have been started on $keyword1 \033[0m\n"
        ssh -q $keyword1 "ps aux | grep "KALProxy.jar" |grep -v grep | awk '{print \$2}'"
        printf "\033[1;31m Waiting for the node $keyword1 to come back online \033[0m\n"
        until curl -s http://kalservloc.postdirect.com/proxy | grep "$keyword1"; do : ; done
        printf "\033[1;31m The Secondary node $keyword1 is now online. \033[0m\n"
        sleep 5
        clear
        printf "\033[1;31m Restarting Primary node $keyword now. \033[0m\n"
        printf "\033[1;31m Current Running Process id's for user KAL@$keyword are: \033[0m\n"
        ssh -q  $keyword "ps aux | grep "KALProxy.jar" |grep -v grep | awk '{print \$2}'"
        printf "\033[1;31m Killing the KALProxy.jar process id's on $keyword \033[0m\n"
        ssh -q  $keyword "sudo kill -9 \$(ps aux | grep "KALProxy.jar" |grep -v grep | awk '{print \$2}')"
        printf "\033[1;31m Checking again if the KALProxy.jar process exists on $keyword \033[0m\n"
        ssh -q $keyword "ps aux | grep "KALProxy.jar" |grep -v grep | wc -l"
        printf "\033[1;31m Starting the service again using user KAL@$keyword \033[0m\n"
        ssh -tq $keyword "sudo su - kal -c '/home/kal/KALProxy/current/start.sh &'"
        sleep 5
        printf "\033[1;31m Confirming if the KALProxy.jar Process have been started on $keyword \033[0m\n"
        ssh -q $keyword "ps aux | grep "KALProxy.jar" |grep -v grep | awk '{print \$2}'"
        printf "\033[1;31m Waiting for the node $keyword to come back online \033[0m\n"
        until curl -s http://kalservloc.postdirect.com/proxy | grep "$keyword"; do : ; done
        printf "\033[1;31m The Primary node $keyword is now online. \033[0m\n"
        sleep 5
        clear
        printf "\033[1;31m The SKAL RESTART for cluster is completed. \033[0m\n"

}

cond2()
{
	printf "\033[1;31m The Primary node for Cluster is $keyword1.\033[0m\n"
        printf "\033[1;31m The Secondary node for Cluster is $keyword.\033[0m\n"
        printf "\033[1;31m Restarting Secondary node $keyword.\033[0m\n"
        printf "\033[1;31m Current Running Process Id's for KAL are: \033[0m\n"
        ssh -q  $keyword "ps aux | grep "KALProxy.jar" |grep -v grep | awk '{print \$2}'"
        printf "\033[1;31m Killing the KALProxy.jar process id's on $keyword \033[0m\n"
        ssh -q  $keyword "sudo kill -9 \$(ps aux | grep "KALProxy.jar" |grep -v grep | awk '{print \$2}')"
        printf "\033[1;31m Checking again if the KALProxy.jar process exists on $keyword \033[0m\n"
        ssh -q $keyword "ps aux | grep "KALProxy.jar" |grep -v grep | wc -l"
        printf "\033[1;31m Starting the service again using user KAL@$keyword \033[0m\n"
        ssh -tq $keyword "sudo su - kal -c '/home/kal/KALProxy/current/start.sh &'"
        sleep 5
        printf "\033[1;31m Confirming if the KALProxy.jar Process have been started on $keyword \033[0m\n"
        ssh -q $keyword "ps aux | grep "KALProxy.jar" |grep -v grep | awk '{print \$2}'"
        printf "\033[1;31m Waiting for the node $keyword to come back online \033[0m\n"
        until curl -s http://kalservloc.postdirect.com/proxy | grep "$keyword"; do : ; done
        printf "\033[1;31m The Secondary node $keyword is now online. \033[0m\n"
        sleep 5
        clear
        printf "\033[1;31m Restarting Primary node $keyword1 now. \033[0m\n"
        printf "\033[1;31m Current Running Process id's for user KAL@$keyword1 are: \033[0m\n"
        ssh -q  $keyword1 "ps aux | grep "KALProxy.jar" |grep -v grep | awk '{print \$2}'"
        printf "\033[1;31m Killing the KALProxy.jar process id's on $keyword1 \033[0m\n"
        ssh -q  $keyword1 "sudo kill -9 \$(ps aux | grep "KALProxy.jar" |grep -v grep | awk '{print \$2}')"
        printf "\033[1;31m Checking again if the KALProxy.jar process exists on $keyword1 \033[0m\n"
        ssh -q $keyword1 "ps aux | grep "KALProxy.jar" |grep -v grep | wc -l"
        printf "\033[1;31m Starting the service again using user KAL@$keyword1 \033[0m\n"
        ssh -tq $keyword1 "sudo su - kal -c '/home/kal/KALProxy/current/start.sh &'"
        sleep 5
        printf "\033[1;31m Confirming if the KALProxy.jar Process have been started on $keyword1 \033[0m\n"
        ssh -q $keyword1 "ps aux | grep "KALProxy.jar" |grep -v grep | awk '{print \$2}'"
        printf "\033[1;31m Waiting for the node $keyword1 to come back online \033[0m\n"
        until curl -s http://kalservloc.postdirect.com/proxy | grep "$keyword1"; do : ; done
        printf "\033[1;31m The Primary node $keyword1 is now online. \033[0m\n"
        sleep 5
        clear
        printf "\033[1;31m The SKAL RESTART for cluster is completed. \033[0m\n"

}

starttime()
{

printf " SKAL Restart for $cluster " > /tmp/SKAL_TIME_$cluster.txt
printf "\n START TIME: `date`\n" >> /tmp/SKAL_TIME_$cluster.txt

START=$(date +%s);

}


endtime()
{

END=$(date +%s);
printf "\n END TIME: `date`\n" >> /tmp/SKAL_TIME_$cluster.txt
runtime=$((END-START))
ACTUALTIME=`printf "\n TIME TAKEN TO RESTART $cluster: %dh:%dm:%ds\n" $(($runtime/3600)) $(($runtime%3600/60)) $(($runtime%60))`
echo $ACTUALTIME >> /tmp/SKAL_TIME_$cluster.txt
cat /tmp/SKAL_TIME_$cluster.txt | mail -s "SKAL Servers $keyword/$keyword1 Restarted for $cluster at `date`" yatin.sawant@infogroup.com;
if [ $? -ne 0 ];
then
        echo "Error in file"
else
        rm /tmp/SKAL_TIME_$cluster.txt
fi		
}





}
while true
do
	display_menu
	read_options
done

