#!/bin/sh

. /usr/local/sysadmin/etc/ym.env
SCRIPTBASE=/usr/local/sysadmin/cseqa
F5=f5.postdirect.com

do_common (){
param=$1
pages=$2
echo "value is \"$param\" and pages value is \"$pages\""

echo "removing ecseqav-apap01 from F5, restarting ecseqav-pages01, adding back to F5"
          ssh -tq $F5 "modify ltm pool pool_cseqa.pages.yesmail.com_80 members modify {$param:80 { session user-disabled } };quit"
          ssh -tq $F5 "modify ltm pool pool_cseqa.pages.yesmail.com_80 members modify {$param:80 { state user-down } };quit"
          sleep 10
          ssh -tq $F5 "run cm config-sync to-group /Common/High-Availability-Pair;quit"
          #ssh -tq $F5 "run cm config-sync to-group /Common/qaf5_ha;quit"
          sleep 60
          ssh -q $param "sudo service httpd graceful"
          sleep 30
          ssh -q $pages "uname -n; sudo /etc/init.d/pages-linux stop; sleep 60; sudo /etc/init.d/pages-linux start"
          sleep 180
          ssh -q $pages "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep pages | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/eprov-pages01.txt
          ssh -tq $F5 "modify ltm pool pool_cseqa.pages.yesmail.com_80 members modify {$param:80 { state user-up } };quit"
          ssh -tq $F5 "modify ltm pool pool_cseqa.pages.yesmail.com_80 members modify {$param:80 { session user-enabled} };quit"
          sleep 10
          ssh -tq $F5 "run cm config-sync to-group /Common/High-Availability-Pair;quit"
          #ssh -tq $F5 "run cm config-sync to-group /Common/qaf5_ha;quit"

}



while :
        do
        cat << !

PRODUCTION RESTART
NOTE: If you use options 1-8, it will put the node live in F5.
Option 11 will leave the appropriate boxes live in the pools.

1.  eprov-apap01
2.  eprov-apap02
3.  eprov-apap03
4.  eprov-apap04
5.  eprov-apap05
6.  eprov-apap06
7.  eprov-apap07
8.  eprov-apap08
9.  QUIT

!

touch /tmp/ELAPSED_TIME/ecseqav-pagesFOO.txt
echo -n " Enter service number: [1-9] "
read SERVNUM

case $SERVNUM in
1) do_common  ecseqav-apap01 ecseqav-pages01;;
2) do_common  ecseqav-apap02 ecseqav-pages02;;
3) do_common  ecseqav-apap03 ecseqav-pages03;;
4) do_common  ecseqav-apap04 ecseqav-pages04;;
5) do_common  ecseqav-apap05 ecseqav-pages05;;
6) do_common  ecseqav-apap06 ecseqav-pages06;;
7) do_common  ecseqav-apap07 ecseqav-pages07;;
8) do_common  ecseqav-apap08 ecseqav-pages08;;
9) exit ;;
*) echo "\"$SERVNUM\" is not valid "; sleep 2 ;;
esac
done
