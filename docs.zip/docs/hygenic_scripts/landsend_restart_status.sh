#!/bin/sh
	
. /usr/local/sysadmin/etc/ym.env
SCRIPTBASE=/usr/local/sysadmin/prod/LANDSEND
 	
#set -x


do_LE_E5UI () {
        echo "restarting LANDSEND E5UI SUPERADMIN"
#        for i in $LANDSEND_UIAPACHE
#          do
#          $SCRIPTBASE/bb-maint2.sh $i http disable 15m restarting n
#        done
        for i in $LANDSEND_SUPERADMIN
          do
#          $SCRIPTBASE/bb-maint2.sh $i \* disable 7m restarting n
          ssh -q $i "uname -n; sudo /etc/init.d/yesconnect-linux restart"
          ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep yesconnect | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/LE_E5UI.txt
        done
}


do_LE_PAGES () {
        echo "restarting LANDSEND PAGES"
#        for i in $LANDSEND_UIAPACHE
#          do
#          $SCRIPTBASE/bb-maint2.sh $i http disable 20m restarting n
#        done
        for i in $LANDSEND_PAGES
          do
#         $SCRIPTBASE/bb-maint2.sh $i \* disable 7m restarting n
          ssh -q $i "uname -n; sudo /etc/init.d/pages-linux stop; sleep 60; sudo /etc/init.d/pages-linux start"
          ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep pages | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/LE_PAGES.txt
        done
}


do_LE_REPORTS () {
        echo "restarting LANDSEND REPORT"
        for i in $LANDSEND_REPORT
          do
#          $SCRIPTBASE/bb-maint2.sh $i \* disable 10m restarting n
          #ssh -q dev@$i "/y/jboss-3.2.7/bin/stopyesconnect; sleep 3; /y/jboss-3.2.7/bin/yesconnect-reports.sh"
          ssh -q dev@$i "/usr/bin/pkill -9 java ; sleep 3; /y/jboss-3.2.7_rls/bin/yesconnect-reports-landsend.sh"
          ssh -q dev@$i "hostname ; echo -n "Process Start time in PDT - "; /usr/bin/ps -ef | grep java | awk '{print \$5 \$6 }'" >> /tmp/ELAPSED_TIME/LE_REPORT.txt
        done
}


do_LE_EVENTS () {
        echo "restarting LANDSEND EVENTS"
        for i in $LANDSEND_EVENTS
          do
#          $SCRIPTBASE/bb-maint2.sh $i \* disable 10m restarting n
          ssh -q $i "uname -n; sudo /etc/init.d/events restart"
          ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep java | grep events | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/LE_EVENTS.txt
        done
}


do_LE_BOUNCE () {
        echo "restarting LANDSEND BOUNCE"
        for i in $LANDSEND_BOUNCE
          do
#          $SCRIPTBASE/bb-maint2.sh $i \* disable 10m restarting n
          ssh -q $i "uname -n; sudo /etc/init.d/scheduler restart"
          ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep java | grep scheduler | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/LE_BOUNCE.txt
        done
}


gen_snapshot () {
   my_pid=$$
   echo "taking LANDSEND GEN snapshot before shutdown "
   echo "$my_pid"
   curl -m 30 -s $url | grep here > /var/tmp/changemaster.$my_pid
   if [ $? -eq 0 ] ; then url=`cut -f 2 -d \" /var/tmp/changemaster.$my_pid` ; fi
   curl -m 30 -s $url  > /var/tmp/monitorsnap.$my_pid
   /usr/bin/uuencode /var/tmp/monitorsnap.$my_pid monitorsnap.${CLUSTER}.html > /var/tmp/mailin.$my_pid
   mail -s "gen snapshot before restart" noc@yesmail.com support-operations@yesmail.com < /var/tmp/mailin.$my_pid
   rm /var/tmp/changemaster.$my_pid /var/tmp/monitorsnap.$my_pid /var/tmp/mailin.$my_pid
}

gen_shutdown () {
   # shutdown delivery before restarting
   echo "doing posting shutdown to LANDSEND gens"
   shuturl=`echo $url | sed s/monitor.jsp/"shutdown.jsp?action=save\&shutDownPassword=d0wn3r"/ `
   /usr/bin/curl -s -m 30 $shuturl
   echo sleeping for 60 letting system shutdown
}

do_LE_GEN () {
        echo "stopping Cluster $GENNUM gens"
        for i in $CLUSTER
          do
#          $SCRIPTBASE/bb-maint2.sh $i \* disable 5m restarting n
          ssh -tq $i "uname -n; sudo /etc/init.d/delivery${GENNUM} stop"
        done
          ssh -tq $CLMASTER "uname -n; sudo /etc/init.d/delivery${GENNUM} start"
          ssh -q $CLMASTER "echo -n "MASTER Elapsed Run Time-";hostname ; ps -eo etime,args | grep delivery${GENNUM} | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/LE_CLUSTER${GENNUM}.txt
          sleep 180
        for i in $CLSLAVE
          do
          ssh -tq $i "uname -n; sudo /etc/init.d/delivery${GENNUM} start"
          ssh -q $i "echo -n "SLAVE Elapsed Run Time-";hostname ; ps -eo etime,args | grep delivery${GENNUM} | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/LE_CLUSTER${GENNUM}.txt
        done
}


do_LE_IMPORT () {
        echo "restarting LANDSEND IMPORT"
        for i in $LANDSEND_IMPORT
          do
#          $SCRIPTBASE/bb-maint2.sh $i \* disable 5m restarting n
          ssh -q $i "uname -n; sudo /etc/init.d/imports stop"
          sleep 30
          ssh -q $i "uname -n; sudo /etc/init.d/imports start"
          ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep import | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/LE_IMPORT.txt
        done
}


do_LE_E7UI () {
        echo "restarting LANDSEND E7 UI"
        for i in $LANDSEND_E7UI
          do
#          $SCRIPTBASE/bb-maint2.sh $i \* disable 10m restarting n
          ssh -q $i "uname -n; sudo /etc/init.d/prod_ui7 restart"
          ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep prod_ui7 | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/LE_E7UI.txt
        done
}


do_LE_MGLND () {
        echo "restarting LANDSEND MAGELLAN SERVICES"
        for i in $LANDSEND_MGLND
          do
#          $SCRIPTBASE/bb-maint2.sh $i \* disable 10m restarting n
          ssh -q $i "uname -n; sudo /etc/init.d/magellan-services restart"
          ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep magellan | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/LE_MGLND.txt
        done
}


do_LE_EAPI_ALL () {
        echo "restarting ALL LANDSEND eAPI"
        for i in $LANDSEND_EAPI_FBE
          do
#          $SCRIPTBASE/bb-maint2.sh $i \* disable 7m restarting n
          ssh -q $i "uname -n; sudo /etc/init.d/ui_ws_rmi restart"
          ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep ui_ws_rmi | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/LE_EAPI_ALL.txt
        done
          sleep 30
        for i in $LANDSEND_EAPI_BE
          do
#          $SCRIPTBASE/bb-maint2.sh $i \* disable 7m restarting n
          ssh -q $i "uname -n; sudo /etc/init.d/jboss restart"
          ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep jboss | grep -v grep | grep -v '/bin/sh' | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/LE_EAPI_ALL.txt
        done
          sleep 30
        for i in $LANDSEND_EAPI_FE
          do
#          $SCRIPTBASE/bb-maint2.sh $i \* disable 7m restarting n
#          ssh -q $i "uname -n; sudo /etc/init.d/aaa-voldemort restart ; sleep 10; sudo /etc/init.d/jboss restart"
          ssh -q $i "uname -n; sudo /etc/init.d/jboss restart"
          ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep jboss | grep -v grep | grep -v '/bin/sh' | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/LE_EAPI_ALL.txt
        done
}

do_LE_EAPI_FBE () {
		echo "restarting LANDSEND eAPI FAR BACK END"
        for i in $LANDSEND_EAPI_FBE
          do
#          $SCRIPTBASE/bb-maint2.sh $i \* disable 7m restarting n
          ssh -q $i "uname -n; sudo /etc/init.d/ui_ws_rmi restart"
          ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep ui_ws_rmi | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/LE_EAPI_FBE.txt
        done
}


do_LE_EAPI_BE () {
		echo "restarting LANDSEND eAPI BACK END"
        for i in $LANDSEND_EAPI_BE
          do
#          $SCRIPTBASE/bb-maint2.sh $i \* disable 7m restarting n
          ssh -q $i "uname -n; sudo /etc/init.d/jboss restart"
          ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep jboss | grep -v grep | grep -v '/bin/sh' | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/LE_EAPI_BE.txt
        done
}



do_LE_EAPI_FE () {
		echo "restarting LANDSEND eAPI FRONT END"
        for i in $EAPI_FE
          do
#          $SCRIPTBASE/bb-maint2.sh $i \* disable 7m restarting n
          ssh -q $i "uname -n; sudo /etc/init.d/jboss restart"
          ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep jboss | grep -v grep | grep -v '/bin/sh' | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/LE_EAPI_FE.txt
        done
}





do_LE_ALL () {
	echo "restarting ALL PRODUCTION LANDSEND"
     	  for db in `seq 13`
	    do
	    GENNUM=$db
	    CLUSTER=`eval echo \\$C${GENNUM}GEN`
	    CLMASTER=`eval echo \\$C${GENNUM}MASTER`
	    CLSLAVE=`eval echo \\$C${GENNUM}SLAVE`
	    do_GEN
	  done	
	do_LE_IMPORT
	do_LE_E5UI
	do_LE_EAPI_ALL
	do_LE_PAGES
	do_LE_BOUNCE
	do_LE_EVENTS
	do_LE_REPORTS
	do_LE_E7UI
	do_LE_MGLND
}

while :
	do
	cat << !

LANDSEND PRODUCTION RESTART

1.  E5 UI Super Admin
2.  PAGES (use landsend_pages_restart_status.sh if you'd like no disruption of service, if it's already down use this)
3.  REPORTS 
4.  EVENTS
5.  BOUNCE
6.  C13 LANDSEND MAILGEN
7.  IMPORT
8.  E7 UI
9.  MAGELLAN SERVICES 
10. ALL eAPI servers (use landsend_eAPI_restartHygienic_status.sh if you'd like no disruption of service, if it's already down use this)
11. eAPI FBE (use landsend_eAPI_restartHygienic_status.sh if you'd like no disruption of service, if it's already down use this)
12. eAPI BE (use landsend_eAPI_restartHygienic_status.sh if you'd like no disruption of service, if it's already down use this)
13. eAPI FE (use landsend_eAPI_restartHygienic_status.sh if you'd like no disruption of service, if it's already down use this)
14. ALL
15. QUIT

!

echo -n " Enter service number: [1-15] "
read SERVNUM

case $SERVNUM in
1) rm /tmp/ELAPSED_TIME/LE_E5UI.txt; do_LE_E5UI; /bin/cat /tmp/ELAPSED_TIME/LE_E5UI.txt | mail -s "LANDSEND E5UI Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
2) rm /tmp/ELAPSED_TIME/LE_PAGES.txt; do_LE_PAGES; /bin/cat /tmp/ELAPSED_TIME/LE_PAGES.txt | mail -s "LANDSEND PAGES Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
3) rm /tmp/ELAPSED_TIME/LE_REPORT.txt; do_LE_REPORTS; /bin/cat /tmp/ELAPSED_TIME/LE_REPORT.txt | mail -s "LANDSEND REPORT Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
4) rm /tmp/ELAPSED_TIME/LE_EVENTS.txt; do_LE_EVENTS; /bin/cat /tmp/ELAPSED_TIME/LE_EVENTS.txt | mail -s "LANDSEND EVENTS Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
5) rm /tmp/ELAPSED_TIME/LE_BOUNCE.txt; do_LE_BOUNCE; /bin/cat /tmp/ELAPSED_TIME/LE_BOUNCE.txt | mail -s "LANDSEND BOUNCE Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
6) CLUSTER=`eval echo \\$LANDSEND_MAILGEN`
   GENNUM=13
   CLMASTER=`eval echo \\$C${GENNUM}MASTER`
   CLSLAVE=`eval echo \\$C${GENNUM}SLAVE`
   url="http://192.168.26.47:8080/pages/monitor.jsp"
   gen_snapshot
   gen_shutdown
   rm /tmp/ELAPSED_TIME/CLUSTER${GENNUM}.txt; do_LE_GEN; /bin/cat /tmp/ELAPSED_TIME/CLUSTER${GENNUM}.txt | mail -s "LANDSEND C13 MAILGEN Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
7) rm /tmp/ELAPSED_TIME/LE_IMPORT.txt; do_LE_IMPORT; /bin/cat /tmp/ELAPSED_TIME/LE_IMPORT.txt | mail -s "LANDSEND IMPORT Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
8) rm /tmp/ELAPSED_TIME/LE_E7UI.txt; do_LE_E7UI; /bin/cat /tmp/ELAPSED_TIME/LE_E7UI.txt | mail -s "LANDSEND E7UI Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
9) rm /tmp/ELAPSED_TIME/LE_MGLND.txt; do_LE_MGLND; /bin/cat /tmp/ELAPSED_TIME/LE_MGLND.txt | mail -s "LANDSEND MAGELLAN SERVICES Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
10) rm /tmp/ELAPSED_TIME/LE_EAPI_ALL.txt; do_LE_EAPI_ALL; /bin/cat /tmp/ELAPSED_TIME/LE_EAPI_ALL.txt | mail -s "ALL LANDSEND EAPI Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
11) rm /tmp/ELAPSED_TIME/LE_EAPI_FBE.txt; do_LE_EAPI_FBE; /bin/cat /tmp/ELAPSED_TIME/LE_EAPI_FBE.txt | mail -s "LANDSEND EAPI FAR BACK END Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
12) rm /tmp/ELAPSED_TIME/LE_EAPI_BE.txt; do_LE_EAPI_BE; /bin/cat /tmp/ELAPSED_TIME/LE_EAPI_BE.txt | mail -s "LANDSEND EAPI BACK END Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
13) rm /tmp/ELAPSED_TIME/LE_EAPI_FE.txt; do_LE_EAPI_FE; /bin/cat /tmp/ELAPSED_TIME/LE_EAPI_FE.txt | mail -s "LANDSEND EAPI FRONT END Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
14) rm /tmp/ELAPSED_TIME/LE*.txt; do_LE_ALL; /bin/cat /tmp/ELAPSED_TIME/LE*.txt | mail -s "ALL LANDSEND PRODUCTION Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
15) exit ;;

*) echo "\"$SERVNUM\" is not valid "; sleep 2 ;;
esac
done
