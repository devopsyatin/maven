#!/bin/sh

. /usr/local/sysadmin/etc/ym.env
SCRIPTBASE=/usr/local/sysadmin/prod/LANDSEND
F5=172.24.10.161

do_eprovlenduiap01 () {
        echo "removing eprov-lenduiap01 from F5, restarting eprov-lendpag01, adding back to F5"
#          $SCRIPTBASE/bb-maint2.sh eprov-lenduiap01 \* disable 7m restarting n
          ssh -tq $F5 "modify ltm pool landsend_http_pool members modify {eprov-lenduiap01:80 { session user-disabled} };quit"
          ssh -tq $F5 "modify ltm pool landsend_http_pool members modify {eprov-lenduiap01:80 { state user-down} };quit"
          sleep 10
          ssh -tq $F5 "run cm config-sync to-group /Common/High-Availability-Pair;quit"
          sleep 600 
          ssh -q eprov-lenduiap01 "sudo /etc/init.d/httpd graceful"
          sleep 30
#          $SCRIPTBASE/bb-maint2.sh eprov-lendpag01 \* disable 7m restarting n
          ssh -q eprov-lendpag01 "uname -n; sudo /etc/init.d/pages-linux stop; sleep 60; sudo /etc/init.d/pages-linux start"
          sleep 180
	  ssh -q eprov-lendpag01 "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep pages | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/eprov-lendpag01.txt
          ssh -tq $F5 "modify ltm pool landsend_http_pool members modify {eprov-lenduiap01:80 { state user-up} };quit"
          ssh -tq $F5 "modify ltm pool landsend_http_pool members modify {eprov-lenduiap01:80 { session user-enabled} };quit"
          sleep 10
          ssh -tq $F5 "run cm config-sync to-group /Common/High-Availability-Pair;quit"
}

do_eprovlenduiap02 () {
        echo "removing eprov-lenduiap02 from F5, restarting eprov-lendpag02, adding back to F5"
#          $SCRIPTBASE/bb-maint2.sh eprov-lenduiap02 \* disable 7m restarting n
          ssh -tq $F5 "modify ltm pool landsend_http_pool members modify {eprov-lenduiap02:80 { session user-disabled} };quit"
          ssh -tq $F5 "modify ltm pool landsend_http_pool members modify {eprov-lenduiap02:80 { state user-down} };quit"
          sleep 10
          ssh -tq $F5 "run cm config-sync to-group /Common/High-Availability-Pair;quit"
          sleep 600
          ssh -q eprov-lenduiap02 "sudo /etc/init.d/httpd graceful"
          sleep 30
#          $SCRIPTBASE/bb-maint2.sh eprov-lendpag02 \* disable 7m restarting n
          ssh -q eprov-lendpag02 "uname -n; sudo /etc/init.d/pages-linux stop; sleep 60; sudo /etc/init.d/pages-linux start"
          sleep 180
	  ssh -q eprov-lendpag02 "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep pages | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/eprov-lendpag02.txt
          ssh -tq $F5 "modify ltm pool landsend_http_pool members modify {eprov-lenduiap02:80 { state user-up} };quit"
          ssh -tq $F5 "modify ltm pool landsend_http_pool members modify {eprov-lenduiap02:80 { session user-enabled} };quit"
          sleep 10
          ssh -tq $F5 "run cm config-sync to-group /Common/High-Availability-Pair;quit"
}

do_ALL () {
        echo "restarting ALL LANDSEND Pages Servers"
        do_eprovlenduiap01
        do_eprovlenduiap02
}

while :
        do
        cat << !

LANDSEND PRODUCTION PAGES RESTART - removes apache front end from f5, http graceful restart, restarts pages server, adds apache front end back to f5 pool 

1.  eprov-lendpag01
2.  eprov-lendpag02
3.  ALL (PAGES Only)
4. QUIT

!

echo -n " Enter service number: [1-4] "
read SERVNUM

case $SERVNUM in
1) rm /tmp/ELAPSED_TIME/eprov-lendpag01.txt; do_eprovlendpag01; /bin/cat /tmp/ELAPSED_TIME/eprov-lendpag01.txt | mail -s "LANDSEND PAGES Server eprov-lendpag01 Restarted at `date`" sysadmin@yesmail.com; exit ;;
2) rm /tmp/ELAPSED_TIME/eprov-lendpag02.txt; do_eprovlendpag02; /bin/cat /tmp/ELAPSED_TIME/eprov-lendpag02.txt | mail -s "LANDSEND PAGES Server eprov-lendpag02 Restarted at `date`" sysadmin@yesmail.com; exit ;;
3) rm /tmp/ELAPSED_TIME/ALL_LE_PAGES.txt; do_ALL; /bin/cat /tmp/ELAPSED_TIME/ALL_LE_PAGES.txt | mail -s "ALL LANDSEND Pages Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
4) exit ;;
*) echo "\"$SERVNUM\" is not valid "; sleep 2 ;;
esac
done

