#!/bin/sh

. /usr/local/sysadmin/etc/ym.env
SCRIPTBASE=/usr/local/sysadmin/prod

#set -x

do_EAPI_E5 () {
        echo "restarting eAPI E5UI"
        for i in $EAPI_E5
          do
          $SCRIPTBASE/bb-maint2.sh $i \* disable 7m restarting n
          ssh -q $i "uname -n; sudo /etc/init.d/ui_ws_rmi restart"
	  ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep ui_ws_rmi | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/EAPI_E5.txt
        done
}

do_EAPI_ALL () {
        echo "restarting eAPI E5UI"
        for i in $EAPI_E5
          do
          $SCRIPTBASE/bb-maint2.sh $i \* disable 7m restarting n
          ssh -q $i "uname -n; sudo /etc/init.d/ui_ws_rmi restart"
	  ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep ui_ws_rmi | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/EAPI_ALL.txt
        done
	  sleep 30
        for i in $EAPI_BE
          do
          $SCRIPTBASE/bb-maint2.sh $i \* disable 7m restarting n
          ssh -q $i "uname -n; sudo /etc/init.d/jboss restart"
	  ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep jboss | grep -v grep | grep -v '/bin/sh' | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/EAPI_ALL.txt
        done
          sleep 30
        for i in $EAPI_FE
          do
          $SCRIPTBASE/bb-maint2.sh $i \* disable 7m restarting n
#          ssh -q $i "uname -n; sudo /etc/init.d/aaa-voldemort restart ; sleep 10; sudo /etc/init.d/jboss restart"
          ssh -q $i "uname -n; sudo /etc/init.d/jboss restart"
	  ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep jboss | grep -v grep | grep -v '/bin/sh' | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/EAPI_ALL.txt
        done
}


do_E5UI () {
	echo "restarting E5UI"
	for i in $UIAPACHE
	  do
	  $SCRIPTBASE/bb-maint2.sh $i http disable 15m restarting n
	done
	for i in $UI
	  do
	  $SCRIPTBASE/bb-maint2.sh $i \* disable 7m restarting n
	  ssh -q $i "uname -n; sudo /etc/init.d/yesconnect-linux restart"
	  ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep yesconnect | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/E5UI.txt
   	done
}

do_PAGES () {
	echo "restarting PAGES"
	for i in $UIAPACHE
	  do
	  $SCRIPTBASE/bb-maint2.sh $i http disable 20m restarting n
	done
	for i in $PAGES
	  do
	  $SCRIPTBASE/bb-maint2.sh $i \* disable 7m restarting n
	  ssh -q $i "uname -n; sudo /etc/init.d/pages-linux stop; sleep 60; sudo /etc/init.d/pages-linux start"
	  ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep pages | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/PAGES.txt
   	done
        for i in $PAGES_MYAPP  
          do
          ssh -tq $i "uname -n; sudo /etc/init.d/pages-linux stop; sleep 60; exit"
	  ssh -tq $i "uname -n; sudo /etc/init.d/pages-linux start"
	  ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep pages | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/PAGES.txt
        done 
	# Work around for problem with eastbay SSL Cert on clcyespage04 - HAL 87183
	#echo -e "\nChecking Foot Locker Eastbay SSL Cert ERROR on clcyespagp04"
	#ssh -q clcyespagp04 "/usr/local/bin/footlocker_check.sh"
}

do_PAGES_WS () {
	echo "restarting PAGES_WS"
	for i in $PAGES_WS
	  do
	  $SCRIPTBASE/bb-maint2.sh $i http disable 15m restarting n
	  ssh -q $i "sudo /etc/init.d/httpd stop; sudo /etc/init.d/pages-ws restart; sleep 240; sudo /etc/init.d/httpd start"
	  ssh -q $i "echo -n "PAGES_WS Elapsed Run Time-";hostname ; ps -eo etime,args | grep pages | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/PAGES_WS.txt
	  ssh -q $i "echo -n "HTTP Elapsed Run Time-";hostname ; ps -eo etime,args | grep http | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/PAGES_WS.txt
	done
}

do_EXCEL () {
	echo "restarting EXCEL"
	for i in $EXCEL
	  do
	  $SCRIPTBASE/bb-maint2.sh $i \* disable 10m restarting n
	  #ssh -q dev@$i "/y/jboss-3.2.7/bin/stopyesconnect; sleep 3; /y/jboss-3.2.7/bin/yesconnect-reports.sh"
	  ssh -q dev@$i "/usr/bin/pkill -9 java ; sleep 3; /y/jboss-3.2.7_rls/bin/yesconnect-reports.sh"
	  ssh -q dev@$i "hostname ; echo -n "Process Start time in PDT - "; /usr/bin/ps -ef | grep java | awk '{print \$5 \$6 }'" >> /tmp/ELAPSED_TIME/EXCEL.txt
   	done
}

do_EVENTS () {
	echo "restarting EVENTS"
	for i in $EVENTS
	  do
	  $SCRIPTBASE/bb-maint2.sh $i \* disable 10m restarting n
	  ssh -q $i "uname -n; sudo /etc/init.d/events restart"
	  ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep java | grep events | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/EVENTS.txt
   	done
}

do_BOUNCES () {
	echo "restarting BOUNCES"
	for i in $BOUNCES
	  do
	  $SCRIPTBASE/bb-maint2.sh $i \* disable 10m restarting n
	  ssh -q $i "uname -n; sudo /etc/init.d/scheduler restart"
	  ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep java | grep scheduler | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/BOUNCES.txt
   	done
}

gen_snapshot () {
   my_pid=$$
   echo "taking snapshot before shutdown "
   echo "$my_pid"
   curl -m 30 -s $url | grep here > /var/tmp/changemaster.$my_pid
   if [ $? -eq 0 ] ; then url=`cut -f 2 -d \" /var/tmp/changemaster.$my_pid` ; fi
   curl -m 30 -s $url  > /var/tmp/monitorsnap.$my_pid
   /usr/bin/uuencode /var/tmp/monitorsnap.$my_pid monitorsnap.${CLUSTER}.html > /var/tmp/mailin.$my_pid
   mail -s "gen snapshot before restart" noc@yesmail.com support-operations@yesmail.com < /var/tmp/mailin.$my_pid
   rm /var/tmp/changemaster.$my_pid /var/tmp/monitorsnap.$my_pid /var/tmp/mailin.$my_pid
}

gen_shutdown () {
   # shutdown delivery before restarting
   echo "doing posting shutdown to gens"
   shuturl=`echo $url | sed s/monitor.jsp/"shutdown.jsp?action=save\&shutDownPassword=d0wn3r"/ `
   /usr/bin/curl -s -m 30 $shuturl
   echo sleeping for 60 letting system shutdown
}

do_GEN () {
	echo "stopping Cluster $GENNUM gens"
        for i in $CLUSTER
          do
	  $SCRIPTBASE/bb-maint2.sh $i \* disable 5m restarting n
	  ssh -tq $i "uname -n; sudo /etc/init.d/delivery${GENNUM} stop"
        done
	  ssh -tq $CLMASTER "uname -n; sudo /etc/init.d/delivery${GENNUM} start"
	  ssh -q $CLMASTER "echo -n "MASTER Elapsed Run Time-";hostname ; ps -eo etime,args | grep delivery${GENNUM} | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/CLUSTER${GENNUM}.txt
          sleep 180
	for i in $CLSLAVE
	  do
	  ssh -tq $i "uname -n; sudo /etc/init.d/delivery${GENNUM} start"
	  ssh -q $i "echo -n "SLAVE Elapsed Run Time-";hostname ; ps -eo etime,args | grep delivery${GENNUM} | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/CLUSTER${GENNUM}.txt
   	done
}

do_IMPORT () {
	echo "restarting IMPORT" 
	for i in $IMPORT
	  do
	  $SCRIPTBASE/bb-maint2.sh $i \* disable 5m restarting n
	  ssh -q $i "uname -n; sudo /etc/init.d/imports stop"
          sleep 30
	  ssh -q $i "uname -n; sudo /etc/init.d/imports start"
	  ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep import | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/IMPORT.txt
   	done
}

do_E6UI () {
	echo "restarting E6UI"
	for i in $E6UI
	  do
	  $SCRIPTBASE/bb-maint2.sh $i \* disable 10m restarting n
	  ssh -q $i "uname -n; sudo /etc/init.d/magellan restart"
	  ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep tomcat | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/E6UI.txt
   	done
}

do_E6THUMB () {
	echo "restarting E6 THUMBNAIL"
	for i in $E6UI
	  do
	  $SCRIPTBASE/bb-maint2.sh $i \* disable 10m restarting n
	  ssh -q $i "uname -n; sudo /etc/init.d/magellan-services restart"
	  ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep magellan | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/E6THUMB.txt
   	done
}

do_SMSTW () {
	echo "restarting SMS TWITTER"
	for i in $SMSTW
	  do
	  $SCRIPTBASE/bb-maint2.sh $i \* disable 10m restarting n
	  ssh -q $i "uname -n; sudo /etc/init.d/magellan-services restart"
	  ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep magellan | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/SMSTW.txt
   	done
}

do_E7UI () {
	echo "restarting E7 UI"
	for i in $E7UI
	  do
	  $SCRIPTBASE/bb-maint2.sh $i \* disable 10m restarting n
	  ssh -q $i "uname -n; sudo /etc/init.d/prod_ui7 restart"
	  ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep prod_ui7 | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/E7UI.txt
   	done
}

do_CSE_clcyescsep01 () {
        echo "restarting clcyescsep01"
        for i in clcyescsep01
          do
          $SCRIPTBASE/bb-maint2.sh $i \* disable 10m restarting n
          ssh -q $i "uname -n; sudo /etc/init.d/tomcat5 restart"
	  ssh -q $i "echo -n "Elapsed Run Time-";hostname ; ps -eo etime,args | grep tomcat5 | grep -v grep | awk '{print \$1}'" >> /tmp/ELAPSED_TIME/CSE_clcyescsep01.txt
        done
}

do_ALL () {
	echo "restarting ALL Enterprise"
     	  for db in `seq 7 12`
	    do
	    GENNUM=$db
	    CLUSTER=`eval echo \\$C${GENNUM}GEN`
	    CLMASTER=`eval echo \\$C${GENNUM}MASTER`
	    CLSLAVE=`eval echo \\$C${GENNUM}SLAVE`
	    do_GEN
	  done	
	do_IMPORT
	do_E5UI
	do_EAPI_ALL
	do_PAGES
	do_BOUNCES
	do_EVENTS
	do_EXCEL
	do_E6UI
	do_E6THUMB
	do_SMSTW
	do_PAGES_WS
}

while :
	do
	cat << !

PRODUCTION RESTART

1.  E5 UI
2.  PAGES (use pages_restart_status_increase.sh)
3.  EXCEL
4.  EVENTS
5.  BOUNCES
6.  DISABLED C6 MAILGEN DO NOT USE
7.  C7 MAILGEN
8.  C8 MAILGEN C8 MAILGEN DO NOT USE
9.  C9 MAILGEN
10. C10 MAILGEN
11. SWARM MAILGEN
12. C12 MAILGEN
13. IMPORT
14. E6 UI
15. E6 THUMBNAILS
16. SMS TWITTER  
17. eAPI servers ( must do manual till script is fixed )
18. PAGES Legacy WS
19. E7 UI
20. CSE clcyescsep01

21. ALL
22. QUIT

!

echo -n " Enter service number: [1-21] "
read SERVNUM

case $SERVNUM in
1) rm /tmp/ELAPSED_TIME/E5UI.txt; do_E5UI; /bin/cat /tmp/ELAPSED_TIME/E5UI.txt | mail -s "E5UI Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
2) rm /tmp/ELAPSED_TIME/PAGES.txt; do_PAGES; /bin/cat /tmp/ELAPSED_TIME/PAGES.txt | mail -s "PAGES Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
3) rm /tmp/ELAPSED_TIME/EXCEL.txt; do_EXCEL; /bin/cat /tmp/ELAPSED_TIME/EXCEL.txt | mail -s "EXCEL Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
4) rm /tmp/ELAPSED_TIME/EVENTS.txt; do_EVENTS; /bin/cat /tmp/ELAPSED_TIME/EVENTS.txt | mail -s "EVENTS Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
5) rm /tmp/ELAPSED_TIME/BOUNCES.txt; do_BOUNCES; /bin/cat /tmp/ELAPSED_TIME/BOUNCES.txt | mail -s "BOUNCE Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
6) /bin/echo "C6GEN servers are deprecated!"
   exit ;;
7) CLUSTER=`eval echo \\$C7GEN`
   GENNUM=7
   CLMASTER=`eval echo \\$C${GENNUM}MASTER`
   CLSLAVE=`eval echo \\$C${GENNUM}SLAVE`
   url="http://192.168.224.57:8080/pages/monitor.jsp"
   gen_snapshot
   gen_shutdown
   rm /tmp/ELAPSED_TIME/CLUSTER${GENNUM}.txt; do_GEN; /bin/cat /tmp/ELAPSED_TIME/CLUSTER${GENNUM}.txt | mail -s "C7GEN Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
8) CLUSTER=`eval echo \\$C8GEN`
   GENNUM=8
   CLMASTER=`eval echo \\$C${GENNUM}MASTER`
   CLSLAVE=`eval echo \\$C${GENNUM}SLAVE`
   url="http://192.168.224.181:8080/pages/monitor.jsp"
   gen_snapshot
   gen_shutdown
   rm /tmp/ELAPSED_TIME/CLUSTER${GENNUM}.txt; do_GEN; /bin/cat /tmp/ELAPSED_TIME/CLUSTER${GENNUM}.txt | mail -s "C8GEN Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
9) CLUSTER=`eval echo \\$C9GEN`
   GENNUM=9
   CLMASTER=`eval echo \\$C${GENNUM}MASTER`
   CLSLAVE=`eval echo \\$C${GENNUM}SLAVE`
   url="http://192.168.224.184:8080/pages/monitor.jsp"
   gen_snapshot
   gen_shutdown
   rm /tmp/ELAPSED_TIME/CLUSTER${GENNUM}.txt; do_GEN; /bin/cat /tmp/ELAPSED_TIME/CLUSTER${GENNUM}.txt | mail -s "C9GEN Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
10) CLUSTER=`eval echo \\$C10GEN`
   GENNUM=10
   CLMASTER=`eval echo \\$C${GENNUM}MASTER`
   CLSLAVE=`eval echo \\$C${GENNUM}SLAVE`
   url="http://192.168.224.187:8080/pages/monitor.jsp"
   gen_snapshot
   gen_shutdown
   rm /tmp/ELAPSED_TIME/CLUSTER${GENNUM}.txt; do_GEN; /bin/cat /tmp/ELAPSED_TIME/CLUSTER${GENNUM}.txt | mail -s "C10GEN Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
11) CLUSTER=`eval echo \\$C11GEN`
   GENNUM=11
   CLMASTER=`eval echo \\$C${GENNUM}MASTER`
   CLSLAVE=`eval echo \\$C${GENNUM}SLAVE`
   url="http://192.168.224.188:8080/pages/monitor.jsp"
   gen_snapshot
   gen_shutdown
   rm /tmp/ELAPSED_TIME/CLUSTER${GENNUM}.txt; do_GEN; /bin/cat /tmp/ELAPSED_TIME/CLUSTER${GENNUM}.txt | mail -s "C11GEN Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
12) CLUSTER=`eval echo \\$C12GEN`
   GENNUM=12
   CLMASTER=`eval echo \\$C${GENNUM}MASTER`
   CLSLAVE=`eval echo \\$C${GENNUM}SLAVE`
   url="http://192.168.224.189:8080/pages/monitor.jsp"
   gen_snapshot
   gen_shutdown
   rm /tmp/ELAPSED_TIME/CLUSTER${GENNUM}.txt; do_GEN; /bin/cat /tmp/ELAPSED_TIME/CLUSTER${GENNUM}.txt | mail -s "C12GEN Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
13) rm /tmp/ELAPSED_TIME/IMPORT.txt; do_IMPORT; /bin/cat /tmp/ELAPSED_TIME/IMPORT.txt | mail -s "IMPORT Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
14) rm /tmp/ELAPSED_TIME/E6UI.txt; do_E6UI; /bin/cat /tmp/ELAPSED_TIME/E6UI.txt | mail -s "E6UI Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
15) rm /tmp/ELAPSED_TIME/E6THUMB.txt; do_E6THUMB; /bin/cat /tmp/ELAPSED_TIME/E6THUMB.txt | mail -s "E6THUMB Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
16) rm /tmp/ELAPSED_TIME/SMSTW.txt; do_SMSTW; /bin/cat /tmp/ELAPSED_TIME/SMSTW.txt | mail -s "SMSTWITTER Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
17) rm /tmp/ELAPSED_TIME/EAPI_ALL.txt; do_EAPI_ALL; /bin/cat /tmp/ELAPSED_TIME/EAPI_ALL.txt | mail -s "eAPI Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
18) rm /tmp/ELAPSED_TIME/PAGES_WS.txt; do_PAGES_WS; /bin/cat /tmp/ELAPSED_TIME/PAGES_WS.txt | mail -s "PAGES_WS Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
19) rm /tmp/ELAPSED_TIME/E7UI.txt; do_E7UI; /bin/cat /tmp/ELAPSED_TIME/E7UI.txt | mail -s "E7UI Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
20) rm /tmp/ELAPSED_TIME/CSE_clcyescsep01.txt; do_CSE_clcyescsep01; /bin/cat /tmp/ELAPSED_TIME/CSE_clcyescsep01.txt | mail -s "CSE clcyescsep01 Restarted at `date`" sysadmin@yesmail.com; exit ;;
21) rm /tmp/ELAPSED_TIME/*.txt; do_ALL; /bin/cat /tmp/ELAPSED_TIME/*.txt | mail -s "ALL ENTERPRISE Servers Restarted at `date`" sysadmin@yesmail.com; exit ;;
22) exit ;;
*) echo "\"$SERVNUM\" is not valid "; sleep 2 ;;
esac
done
