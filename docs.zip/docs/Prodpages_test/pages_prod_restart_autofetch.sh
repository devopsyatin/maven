#!/bin/sh
#set -x
#This Script is for automation of the restart of PRODUCTION PAGES RESTART.
#Writer of the script is YATIN SAWANT - OFFSHORE ASA CYBAGE TEAM
#If any Changes/modifications required in this script,Kindly get in touch with the Yatin Sawant or email at yatin.sawant@infogroup.com

F5=f5.postdirect.com
pool=control_http_pool
clear

display_menu()
{
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "      PRODUCTION PAGES RESTART SCRIPT         "
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "1. PagesServer1"
echo "2. PagesServer2"
echo "3. PagesServer3"
echo "4. PagesServer4"
echo "5. All(one at a time)"
echo "6. Group1-PagesServer1 & PagesServer2 (Restart in group of 2)"
echo "7. Group2-PagesServer3 & PagesServer4 (Restart in group of 2)"
echo "8. Exit"

read_options() {
read -p "Enter Choice [1 -8] :  " choice
case $choice in
        1) set01;;
        2) set02;;
        3) set03;;
        4) set04;;
        5) onebyone;;
	6) setGroup1;;
	7) setGroup2;;
	8) exit 0;;	
        *) echo " " ; echo "Re-run script with proper choice/options" ; exit 0;;
esac
}

pause(){
        read -p "Press [Enter] key for Main Menu ..." factEnterkey
        display_menu
        read_options
}


restart_F5Enable()
{
        ssh -tq $i "sudo /etc/init.d/httpd graceful"
	ssh -tq $i "sudo systemctl restart httpd.service"
        sleep 30
        
	printf "\033[1;31m Current Running Process id for pages on $j are: \033[0m\n"
	ssh -q $j "ps aux | grep "pages" |grep -v grep | awk '{print \$2}'"
	printf "\033[1;31m Stopping the pages process id on $j \033[0m\n"
	ssh -tq $j "sudo /etc/init.d/pages-linux stop"
	
	printf "\033[1;31m Checking again if the pages process exists on $j \033[0m\n"
	test=`ssh -q $j "ps aux | grep "pages" |grep -v grep | wc -l"` && echo $test
		
	if [ $test -ne 0 ]; then
	echo "Process is not killed. Forcefully killing the process."
	ssh -q  $j "sudo kill -9 \$(ps aux | grep "pages" |grep -v grep | awk '{print \$2}')"
	sleep 5
	else
	echo "All Processes killed"
	fi
		
	printf "\033[1;31m Starting the pages process id on $j \033[0m\n"
	ssh -tq $j "sudo /etc/init.d/pages-linux start"
	printf "\033[1;31m Confirming if the Pages Process have been started on $j \033[0m\n"
	ssh -q $j "ps aux | grep "pages" |grep -v grep | awk '{print \$2}'"
	test=`ssh -q $j "ps aux | grep "pages" |grep -v grep | wc -l"` && echo $test

        if [ $test -ne 0 ]; then
        echo "Process Started"
        else
        echo "Process not started. Kindly Investigate."
        exit
        fi
				
        ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { state user-up } };quit"
        ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { session user-enabled} };quit"
        ssh -tq $F5 "run cm config-sync to-group /Common/High-Availability-Pair;quit"
        ASTATE=`ssh -tq $F5 "show ltm pool $pool members {$i:80} all-properties" |grep "State          :" |cut -d":" -f2 |awk ' {print $1} '`
        until [ "$ASTATE" == "enabled" ]; do
        echo "node is $ASTATE"
        echo "F5 is `ssh -tq $F5 'show cm sync-status' |grep "Status  " |awk '{print $2$3}'`"
        done
}

restart_F5Enable1()
{
ssh -tq $j "sudo /etc/init.d/httpd graceful"
ssh -tq $j "sudo systemctl restart httpd.service"
sleep 30

printf "\033[1;31m Current Running Process id for pages on $k are: \033[0m\n"
ssh -q $k "ps aux | grep "pages" |grep -v grep | awk '{print \$2}'"

printf "\033[1;31m Current Running Process id for pages on $l are: \033[0m\n"
ssh -q $l "ps aux | grep "pages" |grep -v grep | awk '{print \$2}'"

printf "\033[1;31m Stopping the pages process id on $k \033[0m\n"
ssh -tq $k "sudo /etc/init.d/pages-linux stop"

printf "\033[1;31m Stopping the pages process id on $l \033[0m\n"
ssh -tq $l "sudo /etc/init.d/pages-linux stop"

printf "\033[1;31m Checking again if the pages process exists on $k \033[0m\n"
test=`ssh -q $k "ps aux | grep "pages" |grep -v grep | wc -l"` && echo $test
		
if [ $test -ne 0 ]; then
echo "Process is not killed. Forcefully killing the process."
ssh -q  $k "sudo kill -9 \$(ps aux | grep "pages" |grep -v grep | awk '{print \$2}')"
sleep 5
else
echo "All Processes killed"
fi

printf "\033[1;31m Checking again if the pages process exists on $l \033[0m\n"
test1=`ssh -q $l "ps aux | grep "pages" |grep -v grep | wc -l"` && echo $test1
		
if [ $test1 -ne 0 ]; then
echo "Process is not killed. Forcefully killing the process."
ssh -q  $l "sudo kill -9 \$(ps aux | grep "pages" |grep -v grep | awk '{print \$2}')"
sleep 5
else
echo "All Processes killed"
fi

printf "\033[1;31m Starting the pages process id on $k \033[0m\n"
ssh -tq $k "sudo /etc/init.d/pages-linux start"

printf "\033[1;31m Confirming if the Pages Process have been started on $k \033[0m\n"
ssh -q $k "ps aux | grep "pages" |grep -v grep | awk '{print \$2}'"

test1=`ssh -q $k "ps aux | grep "pages" |grep -v grep | wc -l"` && echo $test1
if [ $test1 -ne 0 ]; then
echo "Process Started"
else
echo "Process not started. Kindly Investigate."
exit
fi

printf "\033[1;31m Starting the pages process id on $l \033[0m\n"
ssh -tq $l "sudo /etc/init.d/pages-linux start"

printf "\033[1;31m Confirming if the Pages Process have been started on $l \033[0m\n"
ssh -q $l "ps aux | grep "pages" |grep -v grep | awk '{print \$2}'"

test1=`ssh -q $l "ps aux | grep "pages" |grep -v grep | wc -l"` && echo $test1
if [ $test1 -ne 0 ]; then
echo "Process Started"
else
echo "Process not started. Kindly Investigate."
exit
fi

sleep 30
ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { state user-up } };quit"
ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { session user-enabled} };quit"
ssh -tq $F5 "modify ltm pool $pool members modify {$j:80 { state user-up } };quit"
ssh -tq $F5 "modify ltm pool $pool members modify {$j:80 { session user-enabled} };quit"
ssh -tq $F5 "run cm config-sync to-group /Common/High-Availability-Pair;quit"
ASTATE1=`ssh -tq $F5 "show ltm pool $pool members {$i:80} all-properties" |grep "State          :" |cut -d":" -f2 |awk ' {print $1} '`
ASTATE2=`ssh -tq $F5 "show ltm pool $pool members {$j:80} all-properties" |grep "State          :" |cut -d":" -f2 |awk ' {print $1} '`
until [ "$ASTATE1" == "enabled" ] && [ "$ASTATE2" == "enabled" ]; do
echo "nodes are "$ASTATE""
echo "F5 is `ssh -tq $F5 'show cm sync-status' |grep "Status  " |awk '{print $2$3}'`"
done

}


starttime()
{

printf " PAGES Restart for $OPTION " > /tmp/PAGESTIME_$OPTION.txt
printf "\n START TIME: `date`\n" >> /tmp/PAGESTIME_$OPTION.txt

START=$(date +%s);

}

endtime()
{

END=$(date +%s);
printf "\n END TIME: `date`\n" >> /tmp/PAGESTIME_$OPTION.txt
runtime=$((END-START))
ACTUALTIME=`printf "\n TIME TAKEN TO RESTART $OPTION : %dh:%dm:%ds\n" $(($runtime/3600)) $(($runtime%3600/60)) $(($runtime%60))`
echo $ACTUALTIME >> /tmp/PAGESTIME_$OPTION.txt
cat /tmp/PAGESTIME_$OPTION.txt | mail -s "PAGES Servers $OPTION Restarted at `date`" ASA@yesmail.com;
if [ $? -ne 0 ];
then
        echo "Error in file"
else
        rm /tmp/PAGESTIME_$OPTION.txt
fi
}



check_connections()

{
active_connections=`ssh -tq $F5 "show ltm pool $pool members {$i:80} all-properties" |grep "|   Current Connections" | awk -F" " '{ print $4 }'`
echo "current active connections are $active_connections"
}



check_connections1()
{
active_connections1=`ssh -tq $F5 "show ltm pool $pool members {$i:80} all-properties" |grep "|   Current Connections" | awk -F" " '{ print $4 }'`
echo "current active connections are $active_connections1"
}

check_connections2()
{
active_connections2=`ssh -tq $F5 "show ltm pool $pool members {$j:80} all-properties" |grep "|   Current Connections" | awk -F" " '{ print $4 }'`
echo "current active connections are $active_connections2"
}

check_nodes()
{
ssh -tq $F5 "show ltm pool $pool members  all-properties" | awk '/Ltm::Pool Member/{nr[NR]; nr[NR+4]}; NR in nr' | cut -d":" -f4,2 |sed s/://g | awk ' NR %2  {printf ("%s ", $0);next} { print }' | awk '{print $1}' > /tmp/nodes_in_pool

for x in `cat /tmp/nodes_in_pool`; do ssh -tq $x cat /etc/httpd/conf/workers.properties| grep "worker.pages.host"| sed 's/^.*=//'; done > /tmp/conn_servers

printf "\nDisplaying All Apache nodes in Pool\n"
cat /tmp/nodes_in_pool;

printf "\nDisplaying Respective all Pages nodes\n"
cat /tmp/conn_servers
}

check_active_nodes()
{
ssh -tq $F5 "show ltm pool $pool members  all-properties" | awk '/Ltm::Pool Member/{nr[NR]; nr[NR+4]}; NR in nr' | cut -d":" -f4,2 |sed s/://g |awk ' NR %2 {printf ("%s ", $0);next} { print }' | grep enabled | awk '{print $1;}' > /tmp/activenodes

printf "\nDisplaying Active Apache nodes in Pool\n"
cat /tmp/activenodes;

for x in `cat /tmp/activenodes`; do ssh -tq $x cat /etc/httpd/conf/workers.properties| grep "worker.pages.host"| sed 's/^.*=//'; done > /tmp/active_conn_servers
printf "\nDisplaying Respective Active Pages nodes\n"
cat /tmp/active_conn_servers

}





onebyone()

{
OPTION="ALL-one_at_a_time"

echo "check the Pages Pool for the PRODUCTION Environment"

check_nodes;

check_active_nodes;

sleep 5;


var1=$(cat /tmp/activenodes)
var2=$(cat /tmp/active_conn_servers)

IFS=$'\n' arr=($(cat /tmp/activenodes))
IFS=$'\n' arr1=($(cat /tmp/active_conn_servers))

starttime;

for i in $var1; do
        for j in $var2; do

if [ $i == ${arr[0]} ] && [ $j == ${arr1[0]} ];
        then
        echo "case 1 $i $j"
	echo "removing $i from F5, restarting $i, adding back to F5";
	ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { session user-disabled } };quit";
	ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { state user-down } };quit";
	ssh -tq $F5 "run cm config-sync to-group /Common/High-Availability-Pair;quit";
	sleep 10;
	SYNC=`ssh -tq $F5 'show cm sync-status' |grep "Status  " |awk '{print $2$3}'`;
	echo "F5 is $SYNC";
	MSTATE=`ssh -tq $F5 "show ltm pool $pool members { $i:80 } all-properties" |grep "State          :"|cut -d":" -f2 |awk ' {print $1} '`;
	if [ "$MSTATE" == "disabled" ];
        then
        echo "All Good to Proceed"

	check_connections;
	
	if [ $active_connections -le 20 ];

        then
                echo "Restarting the node"
                restart_F5Enable;
        else

                while [ $active_connections -gt 21 ];
                do
                sleep 20
                check_connections;
                done
                restart_F5Enable;
        fi
	else
	echo "Something is not right"
	fi

elif [ $i == ${arr[1]} ] && [ $j == ${arr1[1]} ];
        then
                echo "case 2 $i $j"
	echo "removing $i from F5, restarting $i, adding back to F5";
        ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { session user-disabled } };quit";
        ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { state user-down } };quit";
        ssh -tq $F5 "run cm config-sync to-group /Common/High-Availability-Pair;quit";
        sleep 10;
        SYNC=`ssh -tq $F5 'show cm sync-status' |grep "Status  " |awk '{print $2$3}'`;
        echo "F5 is $SYNC";
        MSTATE=`ssh -tq $F5 "show ltm pool $pool members { $i:80 } all-properties" |grep "State          :"|cut -d":" -f2 |awk ' {print $1} '`;
        if [ "$MSTATE" == "disabled" ];
        then
        echo "All Good to Proceed"

        check_connections;

        if [ $active_connections -le 20 ];

        then
                echo "Restarting the node"
                restart_F5Enable;
        else

                while [ $active_connections -gt 21 ];
                do
                sleep 20
                check_connections;
                done
                restart_F5Enable;
        fi
        else
        echo "Something is not right"
        fi


elif [ $i == ${arr[2]} ] && [ $j == ${arr1[2]} ];
        then
                echo "case 3 $i $j"
       echo "removing $i from F5, restarting $i, adding back to F5";
       ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { session user-disabled } };quit";
       ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { state user-down } };quit";
       ssh -tq $F5 "run cm config-sync to-group /Common/High-Availability-Pair;quit";
       sleep 10;
       SYNC=`ssh -tq $F5 'show cm sync-status' |grep "Status  " |awk '{print $2$3}'`;
       echo "F5 is $SYNC";
       MSTATE=`ssh -tq $F5 "show ltm pool $pool members { $i:80 } all-properties" |grep "State          :"|cut -d":" -f2 |awk ' {print $1} '`;
       if [ "$MSTATE" == "disabled" ];
       then
       echo "All Good to Proceed"

       check_connections;

       if [ $active_connections -le 20 ];

       then
              echo "Restarting the node"
              restart_F5Enable;
       else

              while [ $active_connections -gt 21 ];
              do
              sleep 20
              check_connections;
              done
              restart_F5Enable;
       fi
       else
       echo "Something is not right"
       fi

elif [ $i == ${arr[3]} ] && [ $j == ${arr1[3]} ];
        then
                echo "case 4 $i $j"
       echo "removing $i from F5, restarting $i, adding back to F5";
       ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { session user-disabled } };quit";
       ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { state user-down } };quit";
       ssh -tq $F5 "run cm config-sync to-group /Common/High-Availability-Pair;quit";
       sleep 10;
       SYNC=`ssh -tq $F5 'show cm sync-status' |grep "Status  " |awk '{print $2$3}'`;
       echo "F5 is $SYNC";
       MSTATE=`ssh -tq $F5 "show ltm pool $pool members { $i:80 } all-properties" |grep "State          :"|cut -d":" -f2 |awk ' {print $1} '`;
       if [ "$MSTATE" == "disabled" ];
       then
       echo "All Good to Proceed"

       check_connections;
 
       if [ $active_connections -le 20 ];

       then
               echo "Restarting the node"
               restart_F5Enable;
       else

               while [ $active_connections -gt 21 ];
               do
               sleep 20
               check_connections;
               done
               restart_F5Enable;
       fi
       else
       echo "Something is not right"
       fi
else
        echo "No other servers"

fi


done
done
endtime;
}

set01()

{
OPTION="PAGESSERVER1"
starttime;

check_nodes;

check_active_nodes;

i=${arr[0]}
j=${arr1[0]}

#i="eprov-apap01"
#j="eprov-pages01"
echo "removing $i from F5, restarting $i, adding back to F5"
ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { session user-disabled } };quit"
ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { state user-down } };quit"
ssh -tq $F5 "run cm config-sync to-group /Common/High-Availability-Pair;quit"
sleep 10
SYNC=`ssh -tq $F5 "show cm sync-status" |grep "Status  " |awk '{print $2$3}'`
echo "F5 is $SYNC"
MSTATE=`ssh -tq $F5 "show ltm pool $pool members {$i:80} all-properties" |grep "State          :" |cut -d":" -f2 |awk ' {print $1} '`
if [ "$MSTATE" == "disabled" ];
        then
        echo "All Good to Proceed"

check_connections;

if [ $active_connections -le 20 ];

        then
                restart_F5Enable;
        else
	
                while [ $active_connections -gt 21 ];
                do
                sleep 20
                check_connections;
                done
                restart_F5Enable;
fi

else
echo "Something is not right"
fi

endtime;
}

set02()

{
OPTION="PAGESSERVER2"
starttime;

check_nodes;

check_active_nodes;

i=${arr[1]}
j=${arr1[1]}

#i="eprov-apap02"
#j="eprov-pages02"
echo "removing $i from F5, restarting $i, adding back to F5"
ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { session user-disabled } };quit"
ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { state user-down } };quit"
ssh -tq $F5 "run cm config-sync to-group /Common/High-Availability-Pair;quit"
sleep 10
SYNC=`ssh -tq $F5 "show cm sync-status" |grep "Status  " |awk '{print $2$3}'`
echo "F5 is $SYNC"
MSTATE=`ssh -tq $F5 "show ltm pool $pool members {$i:80} all-properties" |grep "State          :" |cut -d":" -f2 |awk ' {print $1} '`
if [ "$MSTATE" == "disabled" ];
        then
        echo "All Good to Proceed"

check_connections;

if [ $active_connections -le 20 ];

        then
                restart_F5Enable;
        else

                while [ $active_connections -gt 21 ];
                do
                sleep 20
                check_connections;
                done
                restart_F5Enable;
fi

else
echo "Something is not right"
fi
endtime;

}

set03()

{
OPTION="PAGESSERVER3"
starttime;

check_nodes;

check_active_nodes;

i=${arr[2]}
j=${arr1[2]}

#i="eprov-apap03"
#j="eprov-pages03"
echo "removing $i from F5, restarting $i, adding back to F5"
ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { session user-disabled } };quit"
ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { state user-down } };quit"
ssh -tq $F5 "run cm config-sync to-group /Common/High-Availability-Pair;quit"
sleep 10
SYNC=`ssh -tq $F5 "show cm sync-status" |grep "Status  " |awk '{print $2$3}'`
echo "F5 is $SYNC"
MSTATE=`ssh -tq $F5 "show ltm pool $pool members {$i:80} all-properties" |grep "State          :" |cut -d":" -f2 |awk ' {print $1} '`
if [ "$MSTATE" == "disabled" ];
        then
        echo "All Good to Proceed"

check_connections;

if [ $active_connections -le 20 ];

        then
                restart_F5Enable;
        else

                while [ $active_connections -gt 21 ];
                do
                sleep 20
                check_connections;
                done
                restart_F5Enable;
fi

else
echo "Something is not right"
fi
endtime;
}

set04()

{
OPTION="PAGESSERVER4"
starttime;

check_nodes;

check_active_nodes;

i=${arr[3]}
j=${arr1[3]}

#i="eprov-apap04"
#j="eprov-pages04"
echo "removing $i from F5, restarting $i, adding back to F5"
ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { session user-disabled } };quit"
ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { state user-down } };quit"
ssh -tq $F5 "run cm config-sync to-group /Common/High-Availability-Pair;quit"
sleep 10
SYNC=`ssh -tq $F5 "show cm sync-status" |grep "Status  " |awk '{print $2$3}'`
echo "F5 is $SYNC"
MSTATE=`ssh -tq $F5 "show ltm pool $pool members {$i:80} all-properties" |grep "State          :" |cut -d":" -f2 |awk ' {print $1} '`
if [ "$MSTATE" == "disabled" ];
        then
        echo "All Good to Proceed"

check_connections;

if [ $active_connections -le 20 ];

        then
                restart_F5Enable;
        else

                while [ $active_connections -gt 21 ];
                do
                sleep 20
                check_connections;
                done
                restart_F5Enable;
fi

else
echo "Something is not right"
fi
endtime;
}

setGroup1()

{

OPTION="GROUP1"

check_nodes;

check_active_nodes;

starttime;

i=${arr[0]}
j=${arr[1]}
k=${arr1[0]}
l=${arr1[1]}

#i=eprov-apap01
#j=eprov-apap02
#k=eprov-pages01
#l=eprov-pages02

echo "removing group1 from F5, restarting group1, adding back to F5"
ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { session user-disabled } };quit"
ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { state user-down } };quit"
ssh -tq $F5 "modify ltm pool $pool members modify {$j:80 { session user-disabled } };quit"
ssh -tq $F5 "modify ltm pool $pool members modify {$j:80 { state user-down } };quit"
ssh -tq $F5 "run cm config-sync to-group /Common/High-Availability-Pair;quit"
sleep 10
SYNC=`ssh -tq $F5 'show cm sync-status' |grep "Status  " |awk '{print $2$3}'`
echo "F5 is $SYNC"
MSTATE01=`ssh -tq $F5 "show ltm pool $pool members {$i:80} all-properties" |grep "State          :" |cut -d":" -f2 |awk ' {print $1} '`
MSTATE02=`ssh -tq $F5 "show ltm pool $pool members {$j:80} all-properties" |grep "State          :" |cut -d":" -f2 |awk ' {print $1} '`
if [ "$MSTATE01" == "disabled" ] && [ "$MSTATE02" == "disabled" ];
          then
        echo "All Good to Proceed"


check_connections1;
check_connections2;


if [[ $active_connections1 -le 20  &&  $active_connections2 -le 20 ]];

        then
                restart_F5Enable1;

        else
                count=0
                Total=5
                until [ $active_connections1 -le 20 ]  &&  [ $active_connections2 -le 20 ];
                do
                sleep 10
                count=$((count + 1))
                if [ $count == $Total ];
                then
                read -p "Do you want to wait more for count to come down? Yes/No" ans
                echo "Your ans is $ans"
                if [ $ans == No ];
                then
                        restart_F5Enable1;
                        exit
                else
                        Total=$((Total + 5))

                check_connections1;
                check_connections2;
                fi
                fi
                done
                restart_F5Enable1;
fi

else
	echo "Something is wrong"
fi
endtime;
}
setGroup2()

{
OPTION="GROUP2"
starttime;

check_nodes;

check_active_nodes;

i=${arr[2]}
j=${arr[3]}
k=${arr1[2]}
l=${arr1[3]}


#i=eprov-apap03
#j=eprov-apap04
#k=eprov-pages03
#l=eprov-pages04

echo "removing group1 from F5, restarting group1, adding back to F5"
ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { session user-disabled } };quit"
ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { state user-down } };quit"
ssh -tq $F5 "modify ltm pool $pool members modify {$j:80 { session user-disabled } };quit"
ssh -tq $F5 "modify ltm pool $pool members modify {$j:80 { state user-down } };quit"
ssh -tq $F5 "run cm config-sync to-group /Common/High-Availability-Pair;quit"
sleep 10
SYNC=`ssh -tq $F5 'show cm sync-status' |grep "Status  " |awk '{print $2$3}'`
echo "F5 is $SYNC"
MSTATE01=`ssh -tq $F5 "show ltm pool $pool members {$i:80} all-properties" |grep "State          :" |cut -d":" -f2 |awk ' {print $1} '`
MSTATE02=`ssh -tq $F5 "show ltm pool $pool members {$j:80} all-properties" |grep "State          :" |cut -d":" -f2 |awk ' {print $1} '`
if [ "$MSTATE01" == "disabled" ] && [ "$MSTATE02" == "disabled" ];
          then
        echo "All Good to Proceed"
check_connections1;
check_connections2;

if [[ $active_connections1 -le 20  &&  $active_connections2 -le 20 ]];

        then
                restart_F5Enable1;

        else
                count=0
                Total=5
                until [ $active_connections1 -le 20 ]  &&  [ $active_connections2 -le 20 ];
                do
                sleep 10
                count=$((count + 1))
                if [ $count == $Total ];
                then
                read -p "Do you want to wait more for count to come down? Yes/No" ans
                echo "Your ans is $ans"
                if [ $ans == No ];
                then
                        restart_F5Enable1;
                        exit
                else
                        Total=$((Total + 5))

                check_connections1;
                check_connections2;
                fi
                fi
                done
                restart_F5Enable1;
fi
else
        echo "Something is wrong"
fi
endtime;
}


}
while true
do
        display_menu
	read_options
done
