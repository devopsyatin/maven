#! /bin/bash
#set -x

var1=$(cat activenodes)
var2=$(cat server2)



IFS=$'\n' arr=($(cat activenodes))
IFS=$'\n' arr1=($(cat server2))

for i in $var1; do
        for j in $var2; do


if [ $i == ${arr[0]} ] && [ $j == ${arr1[0]} ];
        then
        echo $i $j

elif [ $i == ${arr[1]} ] && [ $j == ${arr1[1]} ];
        then
        echo $i $j

elif [ $i == ${arr[2]} ] && [ $j == ${arr1[2]} ];
        then
        echo $i $j

elif [ $i == ${arr[3]} ] && [ $j == ${arr1[3]} ];
        then
        echo $i $j

#elif [ $i == ${arr[4]} ] && [ $j == ${arr1[4]} ];
#        then
#        echo $i $j

#elif [ $i == ${arr[5]} ] && [ $j == ${arr1[5]} ];
#        then
#        echo $i $j

#elif [ $i == ${arr[6]} ] && [ $j == ${arr1[6]} ];
#        then
#        echo $i $j

#elif [ $i == ${arr[7]} ] && [ $j == ${arr1[7]} ];
#        then
#        echo $i $j

else

        echo "No others"
fi

done

done
