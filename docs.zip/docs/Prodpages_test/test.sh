#! /bin/bash


ssh -tq $QAF5 "show ltm pool $pool members  all-properties" | awk '/Ltm::Pool Member/{nr[NR]; nr[NR+4]}; NR in nr' | cut -d":" -f4,2 |sed s/://g |awk ' NR %2 {printf ("%s ", $0);next} { print }' | grep enabled | awk '{print $1;}' > activenodes

for x in `cat activenodes`; do ssh -tq $x cat /etc/httpd/conf/workers.properties| grep "worker.yesmail.host"| sed 's/^.*=//'; done > server2


var1=$(cat activenodes)
var2=$(cat server2)

#A=`sed -n 1p activenodes | cut -d" " -f2`
#B=`sed -n 2p activenodes | cut -d" " -f2`
#C=`sed -n 3p activenodes | cut -d" " -f2`
#D=`sed -n 4p activenodes | cut -d" " -f2`

#U=`sed -n 1p server2`
#V=`sed -n 2p server2`
#X=`sed -n 3p server2`
#Y=`sed -n 4p server2`


#echo $A
#echo $B
#echo $X
#echo $Y

for i in $var1; do
        for j in $var2; do

if [ $i == $j ] && [ $j == $U ];
        then
        echo "case 1 $i $j"
elif [ $i == $B ] && [ $j == $V ]
	then
	echo "case 2 $i $j"
elif [ $i == $C ] && [ $j == $X ]
	then
        echo "case 3 $i $j"
elif [ $i == $D ] && [ $j == $Y ]
	then
        echo "case 4 $i $j"
else
	echo "No others"
fi
done
done

