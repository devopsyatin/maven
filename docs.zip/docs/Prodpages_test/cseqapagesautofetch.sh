#!/bin/sh
#set -x
QAF5=eqav-f5.postdirect.com
pool=pool_cseqa.pages.yesmail.com_80

clear

display_menu()
{
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "      CSEQA PAGES RESTART SCRIPT         "
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo "1. CSEQAPagesServer1"
echo "2. CSEQAPagesServer2"
echo "3. CSEQAPagesServer3"
echo "4. CSEQAPagesServer4"
echo "5. All(one at a time)"
echo "6. Group1-CSEQAPagesServer1 & CSEQAPagesServer2 (Restart in group of 2)"
echo "7. Group2-CSEQAPagesServer3 & CSEQAPagesServer4 (Restart in group of 2)"
echo "8. Exit"

read_options() {
read -p "Enter Choice [1 -8] :  " choice
case $choice in
        1) set01;;
        2) set02;;
        3) set03;;
        4) set04;;
        5) onebyone;;
        6) setGroup1;;
        7) setGroup2;;
        8) exit 0;;
        *) echo " " ; echo "Re-run script with proper choice/options" ; exit 0;;
esac
}

pause(){
        read -p "Press [Enter] key for Main Menu ..." factEnterkey
        display_menu
        read_options
}

restart_F5Enable()
{
        ssh -tq $i "sudo /etc/init.d/httpd status"
        sleep 30
        ssh -tq $j "sudo /etc/init.d/pages-linux status"
        ssh -tq $QAF5 "modify ltm pool $pool members modify {$i:80 { state user-up } };quit"
        ssh -tq $QAF5 "modify ltm pool $pool members modify {$i:80 { session user-enabled} };quit"
        ssh -tq $QAF5 "run cm config-sync to-group /Common/qaf5_ha;quit"
        ASTATE=`ssh -tq $QAF5 "show ltm pool $pool members {$i:80} all-properties" |grep "State          :" |cut -d":" -f2 |awk ' {print $1} '`
        until [ "$ASTATE" == "enabled" ]; do
        echo "node is "$ASTATE""
        echo "F5 is `ssh -tq $QAF5 'show cm sync-status' |grep "Status  " |awk '{print $2$3}'`"
        done
}

check_connections()
{
active_connections=`ssh -tq $QAF5 "show ltm pool $pool members {$i:80} all-properties" |grep "|   Current Connections" | awk -F" " '{ print $4 }'`
echo "current active connections are $active_connections"
}


check_nodes()
{
ssh -tq $QAF5 "show ltm pool $pool members  all-properties" | awk '/Ltm::Pool Member/{nr[NR]; nr[NR+4]}; NR in nr' | cut -d":" -f4,2 |sed s/://g | awk ' NR %2  {printf ("%s ", $0);next} { print }' | awk '{print $1}' > nodes_in_pool

for x in `cat nodes_in_pool`; do ssh -tq $x cat /etc/httpd/conf/workers.properties| grep "worker.yesmail.host"| sed 's/^.*=//'; done > conn_servers

printf "\nDisplaying All nodes in Pool\n"
cat nodes_in_pool;

printf "\nDisplaying Respective all Apache nodes\n"
cat conn_servers
}

check_active_nodes()
{
ssh -tq $QAF5 "show ltm pool $pool members  all-properties" | awk '/Ltm::Pool Member/{nr[NR]; nr[NR+4]}; NR in nr' | cut -d":" -f4,2 |sed s/://g |awk ' NR %2 {printf ("%s ", $0);next} { print }' | grep enabled | awk '{print $1;}' > activenodes

printf "\nDisplaying Active nodes in Pool\n"
cat activenodes;

for x in `cat activenodes`; do ssh -tq $x cat /etc/httpd/conf/workers.properties| grep "worker.yesmail.host"| sed 's/^.*=//'; done > active_conn_servers
printf "\nDisplaying Respective Active Apache nodes\n"
cat active_conn_servers


}
onebyone()

{
OPTION="ALL(one at a time)"

echo "check the Pages Pool for the CSEQA Environment"

#ssh -tq $QAF5 "show ltm pool $pool members  all-properties" | awk '/Ltm::Pool Member/{nr[NR]; nr[NR+4]}; NR in nr' | cut -d":" -f4,2 |sed s/://g |awk ' NR %2 {printf ("%s ", $0);next} { print }' | grep enabled | awk '{print $1;}' > activenodes

#for x in `cat activenodes`; do ssh -tq $x cat /etc/httpd/conf/workers.properties| grep "worker.yesmail.host"| sed 's/^.*=//'; done > server2

check_nodes;

check_active_nodes;


sleep 5;

var1=$(cat activenodes)
var2=$(cat active_conn_servers)

IFS=$'\n' arr=($(cat activenodes))
IFS=$'\n' arr1=($(cat active_conn_servers))

for i in $var1; do
        for j in $var2; do

if [ $i == ${arr[0]} ] && [ $j == ${arr1[0]} ];
        then
        printf "\ncase 1 $i $j\n"
        echo "removing $i from F5, restarting $i, adding back to F5";
	ssh -tq $QAF5 "modify ltm pool $pool members modify {$i:80 { session user-disabled } };quit";
        ssh -tq $QAF5 "modify ltm pool $pool members modify {$i:80 { state user-down } };quit";
        ssh -tq $QAF5 "run cm config-sync to-group /Common/qaf5_ha;quit";
        sleep 10;
        SYNC=`ssh -tq $QAF5 'show cm sync-status' |grep "Status  " |awk '{print $2$3}'`;
        echo "F5 is $SYNC";
        MSTATE=`ssh -tq $QAF5 "show ltm pool $pool members { $i:80 } all-properties" |grep "State          :"|cut -d":" -f2 |awk ' {print $1} '`;
        if [ "$MSTATE" == "disabled" ];
        then
        echo "All Good to Proceed"

        check_connections;

        if [ $active_connections -le 20 ];

        then
                echo "Restarting the node"
                restart_F5Enable;
        else

                while [ $active_connections -gt 21 ];
                do
                sleep 20
                check_connections;
                done
                restart_F5Enable;
        fi
        else
        echo "Something is not right"
        fi

elif [ $i == ${arr[1]} ] && [ $j == ${arr1[1]} ];
	then
                echo "case 2 $i $j"
        echo "removing $i from F5, restarting $i, adding back to F5";
        ssh -tq $QAF5 "modify ltm pool $pool members modify {$i:80 { session user-disabled } };quit";
        ssh -tq $QAF5 "modify ltm pool $pool members modify {$i:80 { state user-down } };quit";
        ssh -tq $QAF5 "run cm config-sync to-group /Common/qaf5_ha;quit";
        sleep 10;
        SYNC=`ssh -tq $QAF5 'show cm sync-status' |grep "Status  " |awk '{print $2$3}'`;
        echo "F5 is $SYNC";
        MSTATE=`ssh -tq $QAF5 "show ltm pool $pool members { $i:80 } all-properties" |grep "State          :"|cut -d":" -f2 |awk ' {print $1} '`;
        if [ "$MSTATE" == "disabled" ];
        then
        echo "All Good to Proceed"

        check_connections;

       if [ $active_connections -le 20 ];

        then
                echo "Restarting the node"
                restart_F5Enable;
        else

                while [ $active_connections -gt 21 ];
                do
                sleep 20
                check_connections;
                done
                restart_F5Enable;
	fi
        else
        echo "Something is not right"
        fi
else
        echo "No other servers"

fi
done
done

}
set01()

{
OPTION="CSEQAPAGESSERVER1"
starttime;

#i="192.168.36.118"
#j="eprov-pages01"

#j=ssh -tq $i cat /etc/httpd/conf/workers.properties| grep "worker.yesmail.host"| sed 's/^.*=//'; done

check_nodes;

check_active_nodes;

i=${arr[0]}
j=${arr1[0]}

echo "removing $i from F5, restarting $i, adding back to F5"
ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { session user-disabled } };quit"
ssh -tq $F5 "modify ltm pool $pool members modify {$i:80 { state user-down } };quit"
ssh -tq $F5 "run cm config-sync to-group /Common/High-Availability-Pair;quit"
sleep 10
SYNC=`ssh -tq $F5 "show cm sync-status" |grep "Status  " |awk '{print $2$3}'`
echo "F5 is $SYNC"
MSTATE=`ssh -tq $F5 "show ltm pool $pool members {$i:80} all-properties" |grep "State          :" |cut -d":" -f2 |awk ' {print $1} '`
if [ "$MSTATE" == "disabled" ];
        then
        echo "All Good to Proceed"

check_connections;

if [ $active_connections -le 20 ];

        then
                restart_F5Enable;
        else

                while [ $active_connections -gt 21 ];
                do
                sleep 20
                check_connections;
                done
                restart_F5Enable;
fi

else
echo "Something is not right"
fi

endtime;
}





}
while true
do
        display_menu
        read_options
done

