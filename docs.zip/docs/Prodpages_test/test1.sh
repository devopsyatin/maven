#!/bin/bash

QAF5=eqav-f5.postdirect.com
pool=pool_cseqa.pages.yesmail.com_80

#ssh -tq eqav-f5.postdirect.com "show ltm pool pool_cseqa.pages.yesmail.com_80 members  all-properties" | awk '/Ltm::Pool Member/{nr[NR]; nr[NR+4]}; NR in nr' | cut -d":" -f4,2 |sed s/://g | awk ' NR %2  {printf ("%s ", $0);next} { print }' | awk '{print $1}' > nodes_in_pool

#for x in `cat nodes_in_pool`; do ssh -tq $x cat /etc/httpd/conf/workers.properties| grep "worker.yesmail.host"| sed 's/^.*=//'; done > all_servers

#IFS=$'\n' arr=($(cat nodes_in_pool))
#IFS=$'\n' arr1=($(cat all_servers))



ssh -tq eqav-f5.postdirect.com "show ltm pool pool_cseqa.pages.yesmail.com_80 members  all-properties" | awk '/Ltm::Pool Member/{nr[NR]; nr[NR+4]}; NR in nr' | cut -d":" -f4,2 |sed s/://g | awk ' NR %2  {printf ("%s ", $0);next} { print }' | awk '{print $1}' > nodes_in_pool

for x in `cat nodes_in_pool`; do ssh -tq $x cat /etc/httpd/conf/workers.properties| grep "worker.yesmail.host"| sed 's/^.*=//'; done > conn_servers

printf "\nDisplaying All nodes in Pool\n"
cat nodes_in_pool;

printf "\nDisplaying Respective Apache nodes\n"
cat conn_servers

#i=${arr[0]}
#j=${arr1[0]}
#k=${arr[1]}
#l=${arr1[1]}
#m=${arr[2]}
#n=${arr1[2]}
#o=${arr[3]}
#p=${arr1[3]}

#j=`ssh -tq $i cat /etc/httpd/conf/workers.properties| grep "worker.yesmail.host"| sed 's/^.*=//'`
#j=`cat jfile.txt`

#echo $i
#echo $j
#echo $k 
#echo $l 
#echo $m 
#echo $n 
#echo $o
#echo $p


#echo "removing $i from F5, restarting $i, adding back to F5"
#ssh -tq $QAF5 "modify ltm pool $pool members modify {$i:80 { session user-disabled } };quit"
#ssh -tq $QAF5 "modify ltm pool $pool members modify {$i:80 { state user-down } };quit"
#ssh -tq $QAF5 "run cm config-sync to-group /Common/qaf5_ha;quit"
#sleep 10
#SYNC=`ssh -tq $QAF5 "show cm sync-status" |grep "Status  " |awk '{print $2$3}'`
#echo "F5 is $SYNC"
#MSTATE=`ssh -tq $QAF5 "show ltm pool $pool members {$i:80} all-properties" |grep "State          :" |cut -d":" -f2 |awk ' {print $1} '`
#if [ "$MSTATE" == "disabled" ];
#        then
#        echo "All Good to Proceed"
#
#check_connections;
#
#if [ $active_connections -le 20 ];
#
#        then
#                restart_F5Enable;
#        else
#
#                while [ $active_connections -gt 21 ];
#                do
#                sleep 20
#                check_connections;
#                done
#                restart_F5Enable;
#fi
#
#else
#echo "Something is not right"
#fi

